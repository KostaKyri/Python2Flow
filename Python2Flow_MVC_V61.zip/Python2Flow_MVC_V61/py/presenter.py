from model import Model
from view import View
import js

class Presenter():

    def __init__(self):
        self.model = Model()
        self.view = View(self)

    def main(self):
        self.view.main()

    ######################################################################################################################################
    # 01) on_flowChartButton_click(self, code) --> wird von Eventhandler flowChartButton ausgelöst, unterscheidet 3 Fälle: 
    #          Syntaxfehler = kein Flowchart + Fehlermeldung in output + Markierung im Editor
    #          Laufzeitfehler = Flowchart + Fehlermeldung in output + MArkierung im Editor + Markierung des Knotens
    #          kein Fehler = Flowchart wird gezeichnet und Animation-Buttons freigegeben 
    # 02) on_anim_Button_click(self,code) --> wird von Eventhandler animButton ausgelöst
    # 03) on_stepanim_Button_click(self,code) --> wird von Eventhandler stepAnimButton ausgelöst
    # 04) sendlineGroupsOverControllerToModel(self, lineGroups) --> speichert lineGroups in Model, nachdem lineGroups in View erstellt wurde
    ######################################################################################################################################
    
    # 01)
    def on_flowChartButton_click(self, code):

        self.view.clearAll()

        
        msg = None
        tj_syntaxError = js.tj_checkSyntax(code)
        #tj_syntaxError = None


        if tj_syntaxError == None:
            code2 = self.model.repeatToForLoop(code)
            try:
                compile(code2, "<string>", "exec")
            except SyntaxError as ex:
                msg = ex.msg
                lineno = ex.lineno
        else:
            msg = tj_syntaxError.msg
            lineno = tj_syntaxError.line+1
        
        self.model.syntaxError = msg

        # Programm hat Syntaxfehler (es werden keine Flowcharts gezeichnet)
        if msg != None:
            self.view.setButtonsState('init')

            errorMessage = f'<span style="color:red;">SyntaxError: {msg} (line {lineno})</span>'
            # Errormessage wird in output ausgegeben & Zeile wird im Editor markiert
            self.view.showOutput(errorMessage)
            js.addMarker(lineno-1,'highlight-red')


        # Programm hat keinen Syntaxfehler:
        else:
            self.model.createFlowChart(code)
            self.view.appendFlowchartToHtml(self.model.nodeObjectMainTree, self.model.nodeObjectFuncTrees, self.model.lineData)

            self.view.setColorTheme()
            self.view.setFunctionsHorizVert()

            # Speichere Originale Width von values, flowchart und function:
            self.view.valuesClientWidth =  js.document.getElementById("values").clientWidth
            self.view.flowchartClienttWidth =  js.document.getElementById("flowchart").clientWidth
            self.view.functionClientWidth =  js.document.getElementById("functions").clientWidth
            # positioniere Functions rechts neben flowcharts:
            self.view.functions.style.left = f'{(self.view.flowchartClienttWidth+70)*self.view.zoomfactor}px'

            for i in range(len(self.view.leaderlines)):
                self.view.leaderlines[i].style.setProperty("font-size", self.view.zoomfactor, "important")

            self.model.code_tracer(code)

           
            output = ""
            for out in self.model.stoutList:
                output += out+"<br>"

            # Programm hat Laufzeitfehler:
            if self.model.sterror_lineno != -1:
                self.view.setButtonsState('init')

                js.addMarker(self.model.sterror_lineno-1,'highlight-red')

                output += '<span style="color:red;">' + self.model.sterror + '</span>'
                for key, value in self.model.nodelinenoAndIds.items():
                    if key  == str(self.model.sterror_lineno):
                        js.document.getElementById(value +'_id').classList.add("highlight_NodesRed")
                        if value[0] != 'm':
                            js.document.getElementById(value[:2] +'_FuncDef_'+ value[1]).click()
            
            #Programm ist fehlerfrei           
            else:
                self.view.setButtonsState('ready')
                #self.model.animate(code)

            self.view.showOutput(output)
   
    # 02)
    def on_anim_Button_click(self,code):
        self.on_flowChartButton_click(code)
        self.model.animate()
        return self.model.n_abfolge, self.model.raw_lines, self.model.lineGroups, self.model.stout_abfolge, self.model.syntaxError, self.model.sterror_lineno

    # 03
    def on_stepanim_Button_click(self,code,init):
        if init:
            self.on_flowChartButton_click(code)
            self.model.animate()
        return self.model.n_abfolge, self.model.raw_lines, self.model.lineGroups, self.model.stout_abfolge, self.model.syntaxError, self.model.sterror_lineno

    # 04)
    def sendlineGroupsOverControllerToModel(self, lineGroups):
        self.model.lineGroups = lineGroups


if __name__ == '__main__':

    #Überschreiben der eingebauten input()-Funktion:
    import builtins
    def p2f_input(input_text):
        userInput = js.prompt(input_text)

        def is_float(string):
            try:
                float_wert = float(string)
                return True
            except ValueError:
                return False

        #Überprüfen, ob der Benutzer auf "Abbrechen" geklickt hat
        if userInput != None:
            if isinstance(userInput,int) or isinstance(userInput,float):
                return userInput
            elif userInput.isdigit():
                return int(userInput)
            elif is_float(userInput):
                return float(userInput)
            else:
                return userInput

    
    builtins.input = p2f_input


    presenter = Presenter()
    presenter.view.setColorTheme()
    presenter.main()