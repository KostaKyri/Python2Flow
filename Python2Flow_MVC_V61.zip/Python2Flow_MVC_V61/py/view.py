import js
from pyodide.ffi.wrappers import add_event_listener
from pyodide.ffi import to_js


class View():

    def __init__(self, presenter):
        
        
        self.window = js.window

        # DOM-Elemente
        self.drawboard = js.document.querySelector('#drawboard')
        self.gutter = js.document.querySelector('#gutter')
        self.values = js.document.querySelector('#values')
        self.flowchart = js.document.querySelector('#flowchart')
        self.functions = js.document.querySelector('#functions')
        self.output = js.document.querySelector('#output')
        self.outputcontainer = js.document.querySelector('#output-container')

        self.flowchart_button = js.document.querySelector('#flowchart_button')
        self.stop_button = js.document.querySelector('#stop_button')
        self.anim_button = js.document.querySelector('#anim_button')
        self.step_anim_button = js.document.querySelector('#step_anim_button')

        self.leaderlines = js.document.getElementsByClassName("leader-line")
        self.zoom_slider = js.document.querySelector('#zoom_slider')
        self.speed_slider = js.document.querySelector('#speed_slider')
        self.switch_blackwhite = js.document.querySelector('#switch_blackwhite')
        self.switch_horizvert = js.document.querySelector('#switch_horizvert')
        self.print_button = js.document.getElementById("print")
        
        # Instanz von Controller
        self.presenter = presenter

        # Variablen für Leaderline-Objekte
        self.lineObjects = []
        self.e_lineObjects = []
        self.f_lineObjects = [[]]
        self.leaderlineCounter = 1

        # Variablen für stepAnim
        self.step = -1
        self.h = [None,None]  #[marker, line]
        self.n_abfolge = []
        self.step_anim_isrunning = False

        # Originale Width von values, flowchart und function bei der Erstellung des flowcharts
        self.valuesClientWidth = 0
        self.flowchartClienttWidth = 0
        self.functionClientWidth = 0

        # Variable für zoom
        self.zoomfactor = 1
        # Farbe Theme
        self.themeColor = "bright"


    def main(self):
        add_event_listener(self.flowchart_button,"click",self.flowChartButton)
        add_event_listener(self.anim_button,"click",self.animButton)
        add_event_listener(self.step_anim_button,"click",self.stepAnimButton)
        add_event_listener(self.stop_button,"click",self.stopAnim)
        add_event_listener(self.zoom_slider,"input",self.zoomEvent)
        add_event_listener(self.switch_blackwhite,"input",self.toggle_blackwhite)
        add_event_listener(self.switch_horizvert,"input",self.toggle_horizvert)

        add_event_listener(self.window,"resize",self.repositionLines)
        add_event_listener(self.gutter,"mousemove",self.repositionLines)
        add_event_listener(self.drawboard,"scroll",self.repositionLines)
   
        add_event_listener(self.print_button,"click",self.printPage)


    # Eventhandler: #######################################################################################################################################
    # A: Eventhandler für Buttons und Sliders in Nav und im Burgermenü
    # 01) flowChartButton(self, event) --> Methode für clickEvent zu flowchart_button
    # 02) animButton(self, event) --> Methode für clickEvent zu anim_button
    # 03) stepAnimButton(self, event) --> Methode für clickEvent zu step_anim_button
    # 04) stopAnim(self, event) --> Methode für clickEvent zu stop_button
    # 05) zoomEvent(self, event) --> Methode für inputEvent zu zoom_slider
    # 06) toggle_blackwhite(self, event) --> Methode für inputEvent zu switch_blackwhite
    # 07) toggle_horizvert(self, event) --> Methode für inputEvent zu switch_horizvert
    # 08) toggle_horizvert(self, event) --> Methode für inputEvent zu switch_horizvert
        
    # B: Eventhandler für events in der Zeichenfläche:
    # 09) openCloseFuncBodyEvent(self, event) --> Methode für clickEvent zum auf- und zuklappen der Funktionen
    # 10) showBox(self, event) --> Methode für clickEvent zum an- und ausschalten der If/For/While-Boxen 
        
    # C: Eventhandler für Repositionierung der LeaderLines
    # 11) repositionLines(self, event) --> Methode für events, welche die Position oder die Grösse
    #     der Flowcharts verändern, damit LeaderLines neu zu positioniert werden können
    ########################################################################################################################################################

  
    # 01)
    def flowChartButton(self, event):
        self.presenter.on_flowChartButton_click(js.getCode())

    # 02)   
    def animButton(self,event):
        n_abfolge, raw_lines, lineGroups, stout_abfolge, syntaxError, sterror_lineno = self.presenter.on_anim_Button_click(js.getCode())
        if syntaxError == None and sterror_lineno == - 1:
            self.setButtonsState('anim')
            self.setOpacityOfFuncboxes(0.1)
            js.highlighter(to_js(n_abfolge),to_js(raw_lines),to_js(lineGroups), to_js(stout_abfolge),None,None,0,1000)

    # 03)
    def stepAnimButton(self,event):
        # Hilfsfunktion:
        def removeClassRecursive(element, className):
            if element.classList.contains(className):
                element.classList.remove(className)
                
            for i in range(element.children.length):
                childElement = element.children[i]
            
                removeClassRecursive(childElement,className)

        self.step_anim_isrunning = True

        if self.step == -1:
            self.n_abfolge, raw_lines, lineGroups, stout_abfolge, syntaxError, sterror_lineno = self.presenter.on_stepanim_Button_click(js.getCode(),True)
            if syntaxError != None or sterror_lineno != -1:
                self.setButtonsState('init')
                self.step_anim_isrunning = False
                return

            self.step += 1
            js.document.getElementById("output").innerHTML = ""
            self.setButtonsState('animstepbystep')
            self.setOpacityOfFuncboxes(0.1)

            parentDiv = js.document.getElementById('drawboard')
            className = 'highlight_Nodes'
            removeClassRecursive(parentDiv,className)
        
        self.n_abfolge, raw_lines, lineGroups, stout_abfolge, syntaxError, sterror_lineno = self.presenter.on_stepanim_Button_click(js.getCode(),False)
   
        if self.step < len(self.n_abfolge)-2 and self.step != -1:
            self.h = js.highlighter2(to_js(self.n_abfolge),to_js(raw_lines),to_js(lineGroups),to_js(stout_abfolge),self.h[0],self.h[1],self.step,1000)
            self.step += 1
        else:
            js.deleteMarker(self.h[0],self.h[1],to_js(self.n_abfolge),self.step,1000,self.n_abfolge[-1][1])
            self.setOpacityOfFuncboxes(0.1)
            self.setButtonsState('ready')
            self.step = -1
            self.h = [None,None]
            self.n_abfolge = []
            self.step_anim_isrunning = False
            
    # 04)
    def stopAnim(self,event):
        self.setButtonsState('ready')
       
        #stoppt stepAnimation:
        if self.step_anim_isrunning:
            js.deleteMarkerAfterStopAnim(self.h[0],self.h[1],to_js(self.n_abfolge),self.step)
            self.step = -1
            self.h = [None,None]
            self.n_abfolge = []
            self.step_anim_isrunning = False
        else:
            js.stop = False

        self.setOpacityOfFuncboxes(1)
  
        funcDefs = js.document.getElementsByClassName("FuncDef")
        for funcDef in funcDefs:
            display = js.window.getComputedStyle(funcDef.nextElementSibling).display
            if display != "none":
                funcDef.click()

    # 05)
    def zoomEvent(self, event):
        if not len(self.lineObjects) == 0:
            self.flowchart.style.transform = f'scale({self.zoom_slider.value})'
            self.functions.style.transform = f'scale({self.zoom_slider.value})'
            self.functions.style.left = f'{int(self.flowchartClienttWidth*float(self.zoom_slider.value)+100)}px'
        
            self.updateLines()

            self.zoomfactor = '10px' if float(self.zoom_slider.value) < 0.75 else '14px'
            for i in range(len(self.leaderlines)):
                self.leaderlines[i].style.setProperty("font-size", self.zoomfactor, "important")

    # 06)
    def toggle_blackwhite(self, event):
        self.setColorTheme()
    
    # 07)
    def toggle_horizvert(self, event):
        self.setFunctionsHorizVert()

    # 08)
    def printPage(self,event):
        menu = js.document.getElementById("nav")
        menu.style.display = "none"
        js.document.body.style.border = "2px solid #777"

        self.updateLines()
        js.window.print()
        menu.style.display = "flex"
        js.document.body.style.border = "none"
        self.updateLines()
    
    # 09)
    def openCloseFuncBodyEvent(self, event):
        f = event.currentTarget
        f.nextElementSibling.classList.toggle("show")
        display = js.window.getComputedStyle(f.nextElementSibling).display

        functionNumber = int(f.id[1])
        if functionNumber < len(self.f_lineObjects):
            if display != "none":
                [line.show("none") for line in self.f_lineObjects[functionNumber]]
            else:
                [line.hide("none") for line in self.f_lineObjects[functionNumber]]
        
        self.updateLines()   
    
    # 10)
    def showBox(self,event):
        f = event.currentTarget
        if 'If' in f.id:
            f.parentNode.classList.toggle("Ifboxshow")
        elif 'For' in f.id:
            f.parentNode.classList.toggle("Forboxshow")
        elif 'While' in f.id:
            f.parentNode.classList.toggle("Whileboxshow")
    
    # 11)
    def repositionLines(self, event):
        if not len(self.lineObjects) == 0:
            self.updateLines()


    # Weitere Methoden: ###################################################################################################################################
    # 13) setButtonsState(self,state) --> Methode, um die Aktionsbuttons in die Zustände 'init', 'ready', 'anim' oder 'animstepbystep'
    # 14) setOpacityOfFuncboxes(self,opacity) --> Methode, um Funktionen für die Animation ein- bzw. auszublenden
    # 15) updateLines(self) --> Methode, um LeaderLines zu repositionieren
    # 16) setColorTheme(self) --> Methode, um zwischen Dark- und Lightmodus zu wechseln
    # 17) setFunctionsHorizVert(self) --> Methode, um Funktionen vertikal oder horizontal anzuornden
    # 18) clearAll(self) --> Methode, um Markierungen im Editor, FLowcharts auf der Zeichenfläche und Text im Ausgabefenster zu löschen
    # 19) showOutput(self,output,errorLine) --> Methode, um print-Ausgaben & evtl. Fehlermeldungen im Ausgabefenster anzuzeigen
    # 20) appendFlowchartToHtml(self,nodesMainTree, nodesFuncTrees, lineData) --> Methode, um Flowcharts zu generieren - braucht die folgenden 3 Methoden:
    #     20a) NodesToHtmlTree(self,nodes) --> erstellt die HTML-Struktur der Knoten des Flussdaigramms
    #     20b) insertSVGs(self,cls) --> fügt svg's in divs der Knoten ein
    #     20c) LinesToHtmlTree(self, lineData) --> generiert alle Leaderlines für das Flowchart + die Datenstruktur lineGroups, welche alle Linien enthält
    #          (inklusive der für die Animation nötigen Connector-Linien) - lineGroups wird über die Controller-Methode 
    #          sendlineGroupsOverControllerToModel(self, lineGroups) an Model geschickt und dort gespeichert
    #     20d) appendIfForWhileBox(self) --> fügt die Boxen für If/For/While hinzu
    ########################################################################################################################################################

    # 13)
    def setButtonsState(self,state):
        if state == 'init':
            js.document.getElementById("flowchart_button").style.display = "block"
            js.document.getElementById("anim_button").style.display = "none"
            js.document.getElementById("step_anim_button").style.display = "none"
            js.document.getElementById("stop_button").style.display = "none"

            js.document.getElementById("flowchart_button-inactive").style.display = "none"
            js.document.getElementById("anim_button-inactive").style.display = "block"
            js.document.getElementById("step_anim_button-inactive").style.display = "block"
            js.document.getElementById("stop_button-inactive").style.display = "block"
        
        elif state == 'ready':
            js.document.getElementById("flowchart_button").style.display = "block"
            js.document.getElementById("anim_button").style.display = "block"
            js.document.getElementById("step_anim_button").style.display = "block"
            js.document.getElementById("stop_button").style.display = "none"

            js.document.getElementById("flowchart_button-inactive").style.display = "none"
            js.document.getElementById("anim_button-inactive").style.display = "none"
            js.document.getElementById("step_anim_button-inactive").style.display = "none"
            js.document.getElementById("stop_button-inactive").style.display = "block"

        elif state == 'anim':
            js.document.getElementById("flowchart_button").style.display = "none"
            js.document.getElementById("anim_button").style.display = "none"
            js.document.getElementById("step_anim_button").style.display = "none"
            js.document.getElementById("stop_button").style.display = "block"

            js.document.getElementById("flowchart_button-inactive").style.display = "block"
            js.document.getElementById("anim_button-inactive").style.display = "block"
            js.document.getElementById("step_anim_button-inactive").style.display = "block"
            js.document.getElementById("stop_button-inactive").style.display = "none"

        elif state == 'animstepbystep':
            js.document.getElementById("flowchart_button").style.display = "none"
            js.document.getElementById("anim_button").style.display = "none"
            js.document.getElementById("step_anim_button").style.display = "block"
            js.document.getElementById("stop_button").style.display = "block"

            js.document.getElementById("flowchart_button-inactive").style.display = "block"
            js.document.getElementById("anim_button-inactive").style.display = "block"
            js.document.getElementById("step_anim_button-inactive").style.display = "none"
            js.document.getElementById("stop_button-inactive").style.display = "none"

    # 14)
    def setOpacityOfFuncboxes(self,opacity):
        funcboxes = js.document.getElementsByClassName("Funcbox")
        for box in funcboxes:
            box.style.opacity = opacity

    # 15)
    def updateLines(self):
        for line in self.lineObjects:
                    line.position()
        for line in self.e_lineObjects:
            if line['lineType'] == 'iff_line':
                line['lineObject'].startSocketGravity = js.document.getElementById(line['ef']).getBoundingClientRect().x - js.document.getElementById(line['source']).getBoundingClientRect().x - js.document.getElementById(line['source']).getBoundingClientRect().width + js.document.getElementById(line['ef']).getBoundingClientRect().width/2
                line['lineObject'].endSocketGravity = js.document.getElementById(line['ef']).getBoundingClientRect().x - js.document.getElementById(line['target']).getBoundingClientRect().x - js.document.getElementById(line['target']).getBoundingClientRect().width + js.document.getElementById(line['ef']).getBoundingClientRect().width/2
            elif line['lineType'] == 'wf_line':
                line['lineObject'].startSocketGravity = js.document.getElementById(line['ef']).getBoundingClientRect().x - js.document.getElementById(line['source']).getBoundingClientRect().x - js.document.getElementById(line['source']).getBoundingClientRect().width + js.document.getElementById(line['ef']).getBoundingClientRect().width/2
                line['lineObject'].endSocketGravity = js.document.getElementById(line['ef']).getBoundingClientRect().x - js.document.getElementById(line['target']).getBoundingClientRect().x - js.document.getElementById(line['target']).getBoundingClientRect().width + js.document.getElementById(line['ef']).getBoundingClientRect().width/2
            elif line['lineType'] == 'wl_line':
                line['lineObject'].endSocketGravity = js.document.getElementById(line['target']).getBoundingClientRect().x - js.document.getElementById(line['el']).getBoundingClientRect().x - js.document.getElementById(line['el']).getBoundingClientRect().width/2

    # 16)  
    def setColorTheme(self):
        if self.switch_blackwhite.checked == True:
            self.themeColor = "dark"
            labels = js.document.querySelectorAll("svg.leader-line text")
            for text in labels:
                text.style.fill = "lightgrey"
            for line in self.lineObjects:
                line.color = "lightgrey"
            
            figures = js.document.querySelectorAll(".figuresvg")
            for figure in figures:
                figure.style.stroke = "lightgrey"
      
            js.Editor.setTheme("ace/theme/idle_fingers")
            self.drawboard.style.backgroundColor = "rgb(50,50,50)"
            self.output.style.backgroundColor = "rgb(50,50,50)"
            self.output.style.color = "lightgrey"
            self.outputcontainer.backgroundColor = "rgb(50,50,50)"
            
        else:
            self.themeColor = "bright"
            labels = js.document.querySelectorAll("svg.leader-line text")
            for text in labels:
                text.style.fill = "black"
            for line in self.lineObjects:
                line.color = "black"
            
            nodetext = js.document.querySelectorAll("svg.nodesvg text")
            for text in nodetext:
                text.style.fill = "black"
            
            nodestroke = js.document.querySelectorAll(".figuresvg")
            for stroke in nodestroke:
                stroke.style.stroke = "black"
            
            js.Editor.setTheme("ace/theme/crimson_editor")
            self.drawboard.style.backgroundColor = "rgb(255,255,255)"
            self.output.style.backgroundColor = "rgb(247,248,248)"
            self.output.style.color = "black"
            self.outputcontainer.style.backgroundColor = "rgb(247,248,248)"

    # 17)
    def setFunctionsHorizVert(self):
        if self.switch_horizvert.checked == True:
            self.functions.style.flexDirection = "row"
        else:
            self.functions.style.flexDirection = "column"
        self.updateLines()

    # 18)
    def clearAll(self):

        #clear FlowChart (Nodes and LeaderLines) in drawboard window
        while (self.flowchart.firstChild):
            self.flowchart.removeChild(self.flowchart.lastChild)
        while (self.functions.firstChild):
            self.functions.removeChild(self.functions.lastChild)
        if len(self.lineObjects) > 0:
            leaderlinedef = js.document.getElementById("leader-line-defs")
            leaderlinedef.parentNode.removeChild(leaderlinedef)

            for line in self.lineObjects:
                line.remove()
            self.leaderlineCounter += len(self.lineObjects)
            self.lineObjects.clear()
            self.e_lineObjects.clear()
            self.f_lineObjects = [[]]
        
        # clear text in output window
        self.output.innerHTML = ''
        self.output.style.color ='white'

        # clear marker in Editor
        js.removeMarker()
   
    # 19)
    def showOutput(self,output):
        self.output.innerHTML = output
   
    # 20)
    def appendFlowchartToHtml(self,nodesMainTree, nodesFuncTrees, lineData):

        self.flowchart.innerHTML = self.NodesToHtmlTree(nodesMainTree)
        for nodes in nodesFuncTrees:
            self.functions.innerHTML += self.NodesToHtmlTree(nodes)
            self.functions.innerHTML += '<br>'
        
        funcDefs = js.document.getElementsByClassName("FuncDef")
        for funcDef in funcDefs:
            add_event_listener(funcDef,"click",self.openCloseFuncBodyEvent)
            funcDef.click()

        divNodeClasses = ['Terminal','Assign','AssignIO','Expression','Call','DefCall','DefCallAssign','DefCallIO','DefCallReturn','IO','For','endFor','If','endIf','While','endWhile','FuncDef','endFunc']
        for cls in divNodeClasses:
            self.insertSVGs(cls)

        for funcDef in funcDefs:
            funcDef.click()

        self.LinesToHtmlTree(lineData)

        self.appendIfForWhileBox()

    # 20a)
    def NodesToHtmlTree(self,nodes):
        if not nodes:
            return None
        value = nodes[0]
        children = nodes[1:]
        if not children:
            if 'value' in value.values:
                return f"<div id = {value.values['id']} class = {value.values['class']}>{value.values['value']}</div>"
            else:
                return f"<div id = {value.values['id']} class = {value.values['class']}></div>"
        child_html = ''.join([self.NodesToHtmlTree(child) for child in children])
        if 'value' in value.values:
            return f"<div id = {value.values['id']} class = {value.values['class']}>{value.values['value']}</div>"
        else:
            return f"<div id = {value.values['id']} class = {value.values['class']}>{child_html}</div>"

    # 20b)
    def insertSVGs(self,cls):
        divs = js.document.getElementsByClassName(cls)
        for div in divs:
            js.createSVG(div)

    # 20c)
    def LinesToHtmlTree(self, lineData):
        func_counter = 0
        lineGroups = {}

        # Erstellen der sichtbaren Linien:
        for key in lineData:
            lineGroups[key] = []
            for line in lineData[key]:
                line_object = js.lineCreator(line)
                lineGroups[key].append([line_object,line['source'],line['target'], line['anchor1'], line['anchor2']])

                self.lineObjects.append(line_object)

                if line['lineType'] == 'iff_line':
                    self.e_lineObjects.append({'lineObject': self.lineObjects[-1], 'lineType': 'iff_line', 'source': line['source'], 'target': line['target'], 'ef': line['ef']})
                elif line['lineType'] == 'wf_line':
                    self.e_lineObjects.append({'lineObject': self.lineObjects[-1], 'lineType': 'wf_line', 'source': line['source'], 'target': line['target'], 'ef': line['ef']})
                elif line['lineType'] == 'wl_line':
                    self.e_lineObjects.append({'lineObject': self.lineObjects[-1], 'lineType': 'wl_line', 'source': line['source'], 'target': line['target'], 'el': line['el']})
                
                if line['source'][0] =='f':
                    if line['source'][1] == str(func_counter):
                        self.f_lineObjects[-1].append(self.lineObjects[-1])
                        self.f_lineObjects[-1][-1].hide('none')
                    else:
                        func_counter += 1
                        self.f_lineObjects.append([])
                        self.f_lineObjects[-1].append(self.lineObjects[-1])
                        self.f_lineObjects[-1][-1].hide('none')


        # Erstellen der unsichtbaren Linien für connectors, break_connectors und vorzeitige return_connectors
        #Linien zwischen Call und Funktion erstellen:
        connectors =[]
        for key in lineData:
            for node_id in lineData[key]:
                if "_Call_" in node_id['source'] and js.document.getElementById(node_id['source']).className in ["DefCall","DefCallAssign","DefCallIO","DefCallReturn"]:
   
                    indices = [i for i, c in enumerate(node_id['source']) if c == "_"]
                    func_name = node_id['source'][indices[1]:indices[2]+1]
                    func_key = [x for x in lineData if func_name in x]

                    connector1 = {'lineType':'connector', 'source':node_id['source'], 'target':lineData[func_key[0]][0]['source'],'anchor1':'right','anchor2':'left','plug':'arrow1'}
                    l1 = js.lineCreator(connector1)
                    connectors.append([l1,node_id['source'],lineData[func_key[0]][0]['source'],"right","right"])
                    self.lineObjects.append(l1)

                    connector2 = {'lineType':'connector', 'source':lineData[func_key[0]][-1]['target'], 'target':node_id['source'],'anchor1':'right','anchor2':'right','plug':'arrow1'}
                    l2 = js.lineCreator(connector2)
                    connectors.append([l2,lineData[func_key[0]][-1]['target'],node_id['source'],"left","right"])
                    self.lineObjects.append(l2)

        #Connectors werden der lineGroupliste hinzugefügt:
        lineGroups["connectors"] = connectors


        #Linien für Breaks erstellen:
        breaks = []
        break_connectors =[]
        i = 0
        for key in lineData:
            for node_id in lineData[key]:
                if "_Break_" in node_id['source']:
                    breaks.append(node_id)
                    for j in range(i,0,-1):
                 
                        if "_For_" in lineData[key][j]['source']:
                            end = lineData[key][j]['source'][:2]+"_endFor_"+lineData[key][j]['source'][-1]
                            break

                        elif "_While_" in lineData[key][j]['source']:
                            end = lineData[key][j]['source'][:2]+"_endWhile_"+lineData[key][j]['source'][-1]
                            break
                        
                    break_connector = {'lineType':'break_line', 'source':node_id['source'], 'target':end,'anchor1':'left','anchor2':'right','plug':'arrow1'}
                    l = js.lineCreator(break_connector)
                    break_connectors.append([l,node_id['source'],end,"left","right"])
                    self.lineObjects.append(l)

                i += 1
            i = 0

        #Connectors werden der lineGroupliste hinzugefügt:
        lineGroups["break_connectors"] = break_connectors


        #Linien für vorzeitige Returns erstellen:
        returns = []
        return_connectors =[]
        i = 0
        for key in lineData:
            for node_id in lineData[key]:
                if "_Return_" in node_id['source']:
                    returns.append(node_id)

                    if not '_endFunc_' in node_id['target']:
                        end = node_id['source'][:2]+"_endFunc_"+node_id['source'][-1]
                        return_connector = {'lineType':'break_line', 'source':node_id['source'], 'target':end,'anchor1':'left','anchor2':'right','plug':'arrow1'}
                        l = js.lineCreator(return_connector)
                        return_connectors.append([l,node_id['source'],end,"left","right"])
                        self.lineObjects.append(l)
                i += 1
            i = 0

        #Connectors werden der lineGroupliste hinzugefügt:
        lineGroups["return_connectors"] = return_connectors

        self.presenter.sendlineGroupsOverControllerToModel(lineGroups)

        print('lineGroups',lineGroups)
        print('lineObjects',self.lineObjects)
              
    # 20d)
    def appendIfForWhileBox(self):
        If = js.document.getElementsByClassName("If")
        For = js.document.getElementsByClassName("For")
        While = js.document.getElementsByClassName("While")

        for node in If:
            add_event_listener(node,'click',self.showBox)
            node.style.cursor = "pointer"

        for node in For:
            add_event_listener(node,'click',self.showBox)
            node.style.cursor = "pointer"
        
        for node in While:
            add_event_listener(node,'click',self.showBox)
            node.style.cursor = "pointer"



   


   



    