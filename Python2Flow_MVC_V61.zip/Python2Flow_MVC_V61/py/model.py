import js
import ast
from P2F_nodevisitor import P2FNodeVisitor, FuncDefVisitor
from animator import Animator
import traceback
from io import StringIO
import sys


class Model():

    def __init__(self):
        # Variablen, welche über controller an view gehen
        # Daten für Flussdiagramm:

        self.code = ''
        self.nodeObjectMainTree = []    #von createFlowChart() generiert
        self.nodeObjectFuncTrees = []   #von createFlowChart() generiert
        self.lineData = {}              #von createFlowChart() generiert
        self.lineGroups = {}            #von view.LinesToHtmlTree() generiert und über controller mit sendlineGroupsOverControllerToModel() in model geschickt

        # Daten für errorhandling:
        self.error_message = ''
        self.error_type = ''
        self.lineno = None
        self.syntaxError = None

        self.sterror = ""
        self.sterror_lineno = -1

        #Daten für animation:
        self.n_abfolge = []
        self.raw_lines = []
        self.stout_abfolge = []
        self.stoutList = []
      

        self.nodelinenoAndIds = {}       #von createFlowChart generiert

        # interne Variable, um lineData zu erstellen
        self.nodeIDList = {}

        #neu:
        self.anim = None
    


    def animate(self):
        #anim = Animator(code,self.nodeIDList,self.lineGroups)
        self.n_abfolge, self.raw_lines, self.stout_abfolge = self.anim.animation()
        #self.n_abfolge, self.raw_lines, self.stout_abfolge, self.stoutList, self.sterror, self.sterror_lineno = self.anim.animation()
        #self.n_abfolge, self.raw_lines, self.stout_abfolge, self.stoutList, self.sterror, self.sterror_lineno = anim.animate()

    def code_tracer(self,code):
        self.anim = Animator(code,self.nodeIDList,self.lineGroups)
        lines_no, funclist = self.anim.funcfinder(code)
        rows, values, error_message, self.stoutList, self.sterror, self.sterror_lineno = self.anim.code_tracer(code,funclist)

        #anim = Animator(code,self.nodeIDList,self.lineGroups)
        # lines_no, funclist = anim.funcfinder(code)
        # rows, values, error_message, self.stout_abfolge, self.stoutList, self.sterror, self.sterror_lineno = anim.code_tracer(code,funclist)

    def createFlowChart(self,code):

        # Aus AST werden nodeObjectMainTree, nodeObjectFuncTrees & nodeIDList erstellt
        formattedcode = self.repeatToForLoop(code)
        tree = ast.parse(formattedcode)
        #print(ast.dump(tree,indent = 2))
        #js.document.querySelector('#drawboard').innerHTML = ast.dump(tree,indent = 2)
        visitor = P2FNodeVisitor()
        visitor.visit(tree)
        self.nodeObjectMainTree = visitor.main_tree
        self.nodeObjectFuncTrees = visitor.func_trees
        self.nodeIDList = visitor.node_ids

        self.lineData = {}
        self.lineGroups = {}

        # Code, um nodelinenoAndIds zu generieren:
        def flatten_list(nested_list):
            flattened_list = []
            for item in nested_list:
                if isinstance(item, list):
                    flattened_list.extend(flatten_list(item))
                else:
                    flattened_list.append(item)
            return flattened_list

        mainTreeFlat = flatten_list(self.nodeObjectMainTree)
        funcTreesFlat = flatten_list(self.nodeObjectFuncTrees)

        for node in mainTreeFlat:
            print('main',node.values)
        
        for node in funcTreesFlat:
            print('func',node.values)
  
        for node in mainTreeFlat:
            if 'lineno' in node.values:
                self.nodelinenoAndIds[str(node.values['lineno'])] = node.values['id']
        
        for node in funcTreesFlat:
            if 'lineno' in node.values:
                self.nodelinenoAndIds[str(node.values['lineno'])] = node.values['id']
        
      
        # mit lineGenerator wird lineData generiert
        for key in self.nodeIDList:
            self.lineData[key] = []
            self.lineGenerator(key,self.nodeIDList[key])

        print('nodeObjectMainTree',self.nodeObjectMainTree)
        print('nodeObjectFuncTrees',self.nodeObjectFuncTrees)
        print('nodeIDList',self.nodeIDList)
        print('nodelinenoAndIds',self.nodelinenoAndIds)
        print('lineData',self.lineData)

    def lineGenerator(self,key,nodes):
        if_stack = []
        lastTrue_stack = []
        for_stack = []
        while_stack = []
        lastTruW_stack = []
        forbidden = ["_TrueIf_","_TruW_","_FalseIf_","_FaalseIf_","_FalsW_","_backLoop_","_ef_","_el_","_Next_"]
            
        for i in range(0,len(nodes)-1):
            if "TrueIf" in nodes[i+1]:
                #Verbindung zwischen If und True-Zweig
                if "IfEl" in nodes[i]:
                    self.lineData[key].append({'lineType':'ifelt_line', 'source':nodes[i], 'target':nodes[i+2],'anchor1':'left', 'anchor2':'top','label':'True', 'plug':'arrow1'})
                elif "IfoEl" in nodes[i]:
                    self.lineData[key].append({'lineType':'ifoelt_line', 'source':nodes[i], 'target':nodes[i+2],'anchor1':'bottom', 'anchor2':'top','label':'True','plug':'arrow1'})
                if_stack.append(nodes[i])
            elif ("FalseIf" in nodes[i+1]) or ("FaalseIf" in nodes[i+1]):
                lastTrue_stack.append(nodes[i])
                if "FaalseIf" in nodes[i+1]:
                    #Verbindung zwischen If und Faalse-Zweig bei IfEl
                    self.lineData[key].append({'lineType':'default_line', 'source':if_stack[-1], 'target':nodes[i+2],'anchor1':'right', 'anchor2':'top','label':'False','plug':'arrow1'})
                
            elif "endIfEl" in nodes[i+1]:
                #Verbindung zwischen False-Zweig und If-Endknoten
                self.lineData[key].append({'lineType':'default_line', 'source':nodes[i], 'target':nodes[i+1],'anchor1':'bottom', 'anchor2':'right','plug':'arrow1'})
                #Verbindung zwischen True-Zweig und If-Endknoten
                self.lineData[key].append({'lineType':'default_line', 'source':lastTrue_stack[-1], 'target':nodes[i+1],'anchor1':'bottom', 'anchor2':'left','plug':'arrow1'})
                if_stack.pop()
                lastTrue_stack.pop()
            elif "endIfoEl" in nodes[i+1]:
                #Verbindung False-Zweig zwischen If und If-Endknoten
                self.lineData[key].append({'lineType':'iff_line', 'source':if_stack[-1], 'target':nodes[i+1],'anchor1':'right', 'anchor2':'right', 'label':'False', 'plug':'arrow1', 'ef':nodes[i]})
                #Verbindung zwischen True-Zweig und If-Endknoten
                self.lineData[key].append({'lineType':'default_line', 'source':lastTrue_stack[-1], 'target':nodes[i+1],'anchor1':'bottom', 'anchor2':'top','plug':'arrow1'})
                if_stack.pop()
                lastTrue_stack.pop()
                
            elif "TruW" in nodes[i+1]:
                #Verbindung zwischen While und True-Zweig
                self.lineData[key].append({'lineType':'ifoelt_line', 'source':nodes[i], 'target':nodes[i+2],'anchor1':'bottom', 'anchor2':'top','label':'True','plug':'arrow1'})
                while_stack.append(nodes[i])
            elif "FalsW" in nodes[i+1]:
                lastTruW_stack.append(nodes[i])
            elif "endWhile" in nodes[i+1]:
                #Verbindung False-Zweig zwischen While und While-Endknoten
                self.lineData[key].append({'lineType':'wf_line', 'source':while_stack[-1], 'target':nodes[i+1],'anchor1':'right', 'anchor2':'right', 'label':'False', 'plug':'arrow1', 'ef':nodes[i-2]})
                #Verbindung zwischen True-Zweig und backLoop-Zweig
                self.lineData[key].append({'lineType':'wl_line', 'source':lastTruW_stack[-1], 'target':while_stack[-1],'anchor1':'bottom', 'anchor2':'left', 'label':'', 'plug':'arrow1', 'el':nodes[i]})
                #Verbindung zwischen backLoop-Zweig und While
                while_stack.pop()
                lastTruW_stack.pop()

            elif "Next" in nodes[i+1]:
                #Verbindung zwischen For und Next-Zweig
                self.lineData[key].append({'lineType':'default_line', 'source':nodes[i], 'target':nodes[i+2],'anchor1':'right', 'anchor2':'top','label':'Next', 'plug':'arrow1'})
                for_stack.append(nodes[i])
            elif "endFor" in nodes[i+1]:
                #Verbindung zwischen Next-Zweig und For
                self.lineData[key].append({'lineType':'for_line', 'source':nodes[i], 'target':for_stack[-1],'anchor1':'bottom', 'anchor2':'bottom', 'plug':'arrow1'})
                #Verbindung zwischen For und endFor
                self.lineData[key].append({'lineType':'done_line', 'source':for_stack[-1], 'target':nodes[i+1],'anchor1':'bottom', 'anchor2':'top','label':'Done', 'plug':'arrow1'})
                for_stack.pop()
            
            elif not any(s in nodes[i] for s in forbidden):
                self.lineData[key].append({'lineType':'default_line', 'source':nodes[i], 'target':nodes[i+1],'anchor1':'bottom', 'anchor2':'top','plug':'arrow1'})
            elif "FuncDef" in nodes[i]:
                self.lineData[key].append({'lineType':'default_line', 'source':nodes[i], 'target':nodes[i+1],'anchor1':'bottom', 'anchor2':'top','plug':'arrow1'})
                #self.lineData.append([nodes[i],nodes[i+1],"bottom","top",None,None])

    def repeatToForLoop(self,code):
        lines = code.strip().split('\n')
        repToForlines = [" "*(len(line) - len(line.lstrip()))+'for i in range('+line[line.find('t')+1:line.find(':')].lstrip()+'):' if line.lstrip().startswith("repeat") and (line.endswith(":") or line.endswith(":\r")) else line for line in lines]
        return '\n'.join(repToForlines)
    

        
