from pyodide.ffi import to_js
from pyodide.ffi.wrappers import add_event_listener
from io import StringIO
import js
import sys
import traceback
import re




class Animator():

    def __init__(self,code,nodeIDList, lineGroups):
        self.code = code
        self.nodeIDList = nodeIDList
        self.lineGroups = lineGroups
        self.lines_no_dict = {}
        self.lineno_print = []

        #neu: restliche Ergebnisse von code_tracer:
        self.rows =[]
        self.values = []
        self.error_message = None

        self.stout_abfolge = []
        self.stoutList = []
        self.sterror = ""
        self.sterror_lineno = -1

        self.n_abfolge = []
        self.raw_lines = []

        #neu: Ergebnisse von funcfinder:
        self.lines_no = []
        self.funclist = {}


    # Erzeugt ein dictionary der definierten Funktionen und dessen Körperzeilen & 
    # eine Liste mit den konkreten Zeilen:
    def funcfinder(self, code):
        
        # Codezeilen mit zugehöriger Zeilennummer werden in eine Liste gespeichert:
        lines = code.split("\n")
        lines_no = []
        for i in range(len(lines)):
            lines_no.append([i,lines[i]])
        
        # Entfernt alle Leerzeilen und alle Zeilen mit Kommentaren. Dann hängt es eine Zeile mit "end" an.
        lines_no = [x for x in lines_no if x[1].strip() != ""]
        lines_no = [x for x in lines_no if not x[1].startswith("#")]
        lines_no.append([lines_no[-1][0]+1,"end"])

        #neu: self.lines_no_dict wird erstellt, um elif-Schleifen zu erkennen
        self.lines_no_dict = {key:value for [key,value] in lines_no}
        # alle lineno mit print-Anweisungen werden gesucht (um output beim animieren zu generieren)
        for key,value in self.lines_no_dict.items():
            if 'print(' in value:
                self.lineno_print.append(key)
        #Initialisiere Variablen für Intendationlevel und Funktions-Stack
        indentationStack = [0]
        functionStack = []
        bodyStartLineStack = []
        funclist = {}
        
        #Finde Funktionsdefinitionen:
        for i in range(len(lines_no)):
            line = lines_no[i]
            indentationLevel = len(line[1]) - len(line[1].lstrip())
    
            if (re.search(r"^\s*def ",line[1]) and not indentationLevel < indentationStack[-1]):
                indentationStack.append(indentationLevel+4)
                line_stripped = line[1].lstrip()
                
                #Found a function definition
                functionName = line_stripped[4:line_stripped.index("(")]
                functionName = functionName.strip()
                bodyStartLine = line[0]
                functionStack.append(functionName)
                bodyStartLineStack.append(bodyStartLine)
            if (re.search(r"^\s*def ",line[1]) and indentationLevel < indentationStack[-1]):
                #Found the end of a function body
                bodyEndLine = lines_no[i-1][0]
            
                functionName = functionStack.pop(-1)
                bodyStartLine = bodyStartLineStack.pop(-1)
                indentationStack.pop(-1)
                funclist[functionName] = [bodyStartLine,bodyEndLine]
                indentationStack.append(indentationLevel+4)
                line_stripped = line[1].lstrip()
                #Found a function definition
                functionName = line_stripped[4:line_stripped.index("(")]
                functionName = functionName.strip()
                bodyStartLine = line[0]
                #bodyEndLine = bodyStartLine
                functionStack.append(functionName)
                bodyStartLineStack.append(bodyStartLine)
            elif (indentationLevel < indentationStack[-1]):
                #Found the end of a function body
                bodyEndLine = lines_no[i-1][0]
            
                functionName = functionStack.pop(-1)
                bodyStartLine = bodyStartLineStack.pop(-1)
                indentationStack.pop(-1)
                funclist[functionName] = [bodyStartLine,bodyEndLine]

        #Dictionary der Funktionen
        for func in funclist:
            list = []
            for line in lines_no:
                if line[0] >= funclist[func][0] and line[0] <= funclist[func][1]:
                    list.append(line[0])
            funclist[func] = list
        
        #Check if there are any functions left on the stack (i.e., functions that were not closed)
        if (len(functionStack) > 0):
            functionName = functionStack.pop(-1)
            print("Error: Function ",functionName," was not closed")
        print("lines_no",lines_no)
        print("funclist",funclist)

        #neu
        self.lines_no = lines_no
        self.funclist = funclist

        return lines_no, funclist

    # Erzeugt eine Liste, in welcher die Reihenfolge der Zeilennummern des Programmablaufs gespeichert sind:
    def code_tracer(self, code, funclist):
        def format_code(code):
            lines = code.rstrip().split('\n')
            ##### neu: umformatieren von Platzhalterimporten:
            for index,line in enumerate(lines):
                if line.startswith("from") and (line.endswith("*") or line.endswith("*\r")):
                    words = line.split()
                    lines[index] = f'import {words[1]}; globals().update(vars({words[1]}))'
            #################################################

            repToForlines = [" "*(len(line) - len(line.lstrip()))+'for i in range('+line[line.find('t')+1:line.find(':')].lstrip()+'):' if line.lstrip().startswith("repeat") and (line.endswith(":") or line.endswith(":\r")) else line for line in lines]
            indented_lines = ['    ' + line for line in repToForlines]
            #indented_lines = ['    ' + line for line in lines]
            formatted_code = '\n'.join(indented_lines)
            #print('def fklwnfldmlkdmwlkemwledmwlkmlwekdm():\n' + formatted_code)
            return 'def fklwnfldmlkdmwlkemwledmwlkmlwekdm():\n' + formatted_code

        def trace_calls_wrapper(funclist):
            def trace_calls(frame, event, arg):
                #print("f",frame.f_code.co_name)
                if event == 'line':
                    #print("f0",frame.f_code.co_name)
                    # lineno = frame.f_lineno
                    # call_stack.append(lineno)
                    if frame.f_code.co_name == 'fklwnfldmlkdmwlkemwledmwlkmlwekdm' or frame.f_code.co_name in funclist:
                        #print("g",frame.f_code.co_name)
                        lineno = frame.f_lineno
                        call_stack.append(lineno)
                        
                        value_stack.append([lineno,[]])
                        locals_list = frame.f_locals
                        for var_name, var_value in locals_list.items():
                            value_stack[-1][1].append([f'{var_name}',f'{var_value}'])
                            #value_stack[-1][1].update({f'{var_name}':f'{var_value}'})
                return trace_calls
            return trace_calls

        
        #fklwnfldmlkdmwlkemwledmwlkmlwekdm = create_function(code)
        f_code = format_code(code)
        namespace = {}
        exec(f_code, namespace)
        foo_func = namespace['fklwnfldmlkdmwlkemwledmwlkmlwekdm']

        call_stack = []
        value_stack = []
        error_message = False

        output_buffer = StringIO()
        stdout_backup = sys.stdout
        sys.stdout = output_buffer




        sys.settrace(trace_calls_wrapper(funclist))
        try:
            foo_func()
        except Exception:
            #error_message = traceback.format_exc()
            error_type, error_value, tb = sys.exc_info()

            error_lineno = traceback.extract_tb(tb)[-1][1]
            error_message = error_value
            error_message_explanation = str(error_message)
            if 'fklwnfldmlkdmwlkemwledmwlkmlwekdm' in str(error_message):
                temp = error_message_explanation.replace('fklwnfldmlkdmwlkemwledmwlkmlwekdm','')
                error_message_explanation = str(temp[10:])
                
            self.sterror = f"{type(error_message).__name__}: {error_message_explanation} (line {str(error_lineno-1)})"
            self.sterror_lineno = error_lineno-1
        sys.settrace(None)

        sys.stdout = stdout_backup
        self.stoutList = output_buffer.getvalue().split("\n")
        #print('stoutList',self.stoutList)

        rows = [x-2 for x in call_stack]
        values = [[x[0]-2,x[1]] for x in value_stack]
        #c = [x-1 for x in call_stack[1:]]
        print("rows",rows)
        print('stoutabfolge',self.stout_abfolge)
        #print("values",values)
        print('stoutList',self.stoutList)
        print('sterror',self.sterror)
        print('sterror_lineno',self.sterror_lineno)

        #neu:
        self.rows =rows
        self.values = values
        self.error_message = error_message

        return rows, values, error_message, self.stoutList, self.sterror, self.sterror_lineno
        
    # Erzeugt eine Liste mit den Knoten in der Reihenfolge, wie sie bei der Ausführung durchlaufen werden:
    def animation(self):
        js.document.getElementById("values").innerHTML = ""

        #neu:
        lines_no, funclist = self.lines_no, self.funclist
        tracer = self.rows, self.values, self.error_message, self.stout_abfolge, self.stoutList # self.sterror, self.sterror_lineno

        # lines_no, funclist = self.funcfinder(js.getCode())
        # tracer = self.code_tracer(js.getCode(),funclist)
        rows = tracer[0]
        values = tracer[1]
        error_message = tracer[2]
        
        print('sterror_lineno',self.sterror_lineno)
        #n = node_generator(js.getCode())
        
        forbidden = ["_Start_","_Stop_","Tru","Fals","end","_backLoop_","_Next_","_e_","_ef_","_el_","_FuncDef_","_endFunc_"]
        n_abfolge = []

        print('rows0',rows)
        
        ### A. Hauptprogramm wird n_abfolge hinzugefügt: ###
        ####################################################
    
        # 1. Bestimmung der Zeilen, die zu Funktionen gehören
        func_body_lines = []
        for f in funclist:
            func_body_lines.extend(funclist[f])
        func_body_lines = set(func_body_lines)
        print('func_body_lines',func_body_lines)
        # Original-Code-Abfolge wird gesichert
        rows_origin = rows.copy()
        
        # 2a. Zeilen von Funktionen werden aus Code-Abfolge rows entfernt
        rows = [x for x in rows if x not in func_body_lines]
        # 2b. rows wird ein Schlusswert hinzugefügt (nötig für Iteration, damit Vergleich nicht out of range geht)
        rows.append(-1)
        print('rows_main',rows)

            
        # 3. Zeilen von Funktionen werden aus Code-Abfolge lines_no[0] (nur Zeilennummern) entfernt
        lines_no0 = [x[0] for x in lines_no]
        for i in func_body_lines:
            for j in lines_no0:
                if i == j:
                    lines_no0.remove(i)

        print('lines_main',lines_no0)
        # 4a. node_ids, die im Code sichtbar sind werden aus node_id extrahiert:
        n_pur = []
        for node_id in self.nodeIDList["m_Start_"]:
            activate = True
            for infix in forbidden:
                if infix in node_id:
                    activate = False
                    break
            if activate:
                n_pur.append(node_id)

        print('n_pur1',n_pur)

        #neu: alle Faalse aus n_pur, die zu elif gehören, werden entfernt
        for i,x in enumerate(lines_no0[:-1]):
            #print(i,'i',x,'x')
            if "_FaalseIf_" in n_pur[i] and "elif" in self.lines_no_dict[x]:
                #print('i',i,'x',x,'n_pur[i]',n_pur[i],'lines_no_dict[x]',self.lines_no_dict[x])
                del n_pur[i]
                #print(len(n_pur))


        #4b. Zuorndung der Zeilennummern:
        n_pur = [[line,node] for line, node in zip(lines_no0, n_pur)]
        print('n_pur2',n_pur)

        #4c. eventuell vorhandenes "else" (id Faalse_If) wird aus n_pur gelöscht.
        n_pur = [x for x in n_pur if "_FaalseIf_" not in x[1]]

        
        #4d. end-node wird hinzugefügt (nötig für Iteration, damit Vergleich nicht out of range geht)
        n_pur.append(lines_no[-1])
        print('n_pur3',n_pur)
        #5. n_abfolge wird mit main gefüllt: ###################################################
        for i in range(1,len(rows)):
            for k in range(len(n_pur)):
                if n_pur[k][0] == rows[i-1]:
                    node1 = n_pur[k]
                    node2 = n_pur[k+1]
                    # Fügt die Werte der lokalen Variablen hinzu - funktioniert noch nicht richtig!!!
                    # node1.append(values[i-1][1])
                    break

            if rows[i] == -1 and error_message:
                n_abfolge.append(node1)
                break
            
            
            ###neu: wegen fehler "UnboundLocalError: local variable 'node1' referenced before assignment"
            if 'node1' in locals():
                #print(node1)
                    
                if "_For_" in node1[1] and not rows[i] == node2[0]:
                    n_abfolge.append(node1)
                    n_abfolge.append([node1[1],"m0_endFor_"+node1[1][-1]])
                elif "_IfoEl_" in node1[1] and not rows[i] == node2[0]:
                    n_abfolge.append(node1)
                    # n_abfolge.append([node1[1],"m0_e_"+node1[1][-1]])
                    n_abfolge.append([node1[1],"m0_endIfoEl_"+node1[1][-1]])
                elif "_While_" in node1[1] and not rows[i] == node2[0]:
                    n_abfolge.append(node1)
                    # n_abfolge.append([node1[1],"m0_ef_"+node1[1][-1]])
                    n_abfolge.append([node1[1],"m0_endWhile_"+node1[1][-1]])
                    
                elif "_Break_" in node1[1]:
                    #print("break entdeckt",node1[1])

                    #Suche rückwärts nach dem nächten While oder For:
                    index_of_break = self.nodeIDList["m_Start_"].index(node1[1])
                    #print('index_of_break',index_of_break)
                    for i in range(index_of_break,-1,-1):
                        if "_For_" in self.nodeIDList["m_Start_"][i] or "_While_" in self.nodeIDList["m_Start_"][i]:
                            end_of_loop = f"{self.nodeIDList['m_Start_'][i][:3]}end{self.nodeIDList['m_Start_'][i][3:]}"
                            print('end_of_loop',end_of_loop)

                            n_abfolge.append(node1)
                            n_abfolge.append([node1[1],end_of_loop])
                            break

                else:
                    n_abfolge.append(node1)

    
        n_abfolge.insert(0,['Start','m0_Start_'])
        if not error_message:
            n_abfolge.append(['Stop','m0_Stop_'])

        print('n_abfolge1',n_abfolge)

        j = 1
        l = len(n_abfolge)
        while j < l:
            if j > 100000:
                js.document.getElementById("values").innerHTML = "<span style='color:red;'>Internal Error - infinite while-Loop in debug, line 339</span>"
                break
            #print(j,l)
            activate = True
            for linepair in self.lineGroups['m_Start_']:
                #print(n_abfolge[j-1][1],linepair[1],n_abfolge[j][1],linepair[2])
            #for linepair in n[1]['m_Start_']:
                if (n_abfolge[j-1][1] == linepair[1] and n_abfolge[j][1] == linepair[2]) or "_Break_" in n_abfolge[j-1][1]:
                    activate = False
                    break
            
            if activate:
                for linepair in self.lineGroups['m_Start_']:
                #for linepair in n[1]['m_Start_']:
                    if linepair[1] == n_abfolge[j-1][1]:
                        n_abfolge.insert(j,[linepair[2],linepair[2]])
                        print('n_abfolge_neu!',n_abfolge)

                        l += 1
                        break
            j += 1
            
        print('n_abfolge2',n_abfolge)


        ### B. Funktionen werden n_abfolge hinzugefügt: ###
        ####################################################
        
        n_func = {}
        rows = rows_origin.copy()
        n_ohne_main = self.nodeIDList.copy()
        n_ohne_main.pop("m_Start_")
        n_f_abfolge = []

        print('n_ohne_main',n_ohne_main)
        
        # 1. Positionen in n_abfolge, an welchen Funktionen aufgerufen werden
        n_call_index = []
        for i in range(len(n_abfolge)):
            #if "_Call_" in n_abfolge[i][1] and js.document.getElementById(n_abfolge[i][1]).className == "DefCall":
            if "_Call_" in n_abfolge[i][1] and js.document.getElementById(n_abfolge[i][1]).className in ["DefCall","DefCallAssign","DefCallIO","DefCallReturn"]:
                n_call_index.append(i)
            
        # 2a. Liste, die den Zeilennummern die Funktion zuordnet (0, wenn keine Funktion)
        c_func = [next((key for key in funclist if element in funclist[key][1:]), 0) for element in rows]
        
        #print('n_call_index',n_call_index)
        #print('c_func',c_func)

        # 2b. aus c_func und c eine Liste aus Listen generieren, die Funktionsname als 1. Element und 
        # Liste von Zeilen des Aufrugs der Funktion als 2.Element enthält, z.B.
        # c_origin [0, 4, 5, 7, 11, 12, 13, 16, 1, 12, 13, 14, 8, 9, 12, 13, 16, 1, 2, 3, 1, 12]
        # c_func [0, 0, 0, 0, 0, 0, 0, 0, 'foo', 0, 0, 0, 'foo2', 'foo2', 0, 0, 0, 'foo', 'foo', 'foo', 'foo', 0]
        # -> c_func_aufrufe [['foo', [1]], ['foo2', [8, 9]], ['foo', [1, 2, 3, 1]]]
        c_func_aufrufe = []
        #Neu: zusätzlich wird eine Liste mit den Funktionsnamen erstellt:
        c_func_namelist = []
        position = 0
        i = 0

        while i < len(c_func):
            #print(2)
            if c_func[i] != 0:
                # c_func_aufrufe.append([c_func[i],[rows[i]]])
                c_func_aufrufe.append([c_func[i],[]])
                c_func_namelist.append([c_func[i],[]])
                func_name = c_func[i]
                # i += 1
                #print("1",i)
                # while i<len(c_func) and c_func[i] == func_name:
                while i<len(c_func) and not rows[i] in lines_no0:

                    c_func_aufrufe[position][1].append(rows[i])
                    c_func_namelist[position][1].append(c_func[i])
                    # print(i,c_func_aufrufe)
                    i += 1
                    #print(i)
                position += 1
            else:
                i += 1
            
        #2c. jeder Funktionsabfolge wird ein Schlusswert hinzugefügt (nötig für Iteration, damit Vergleich nicht out of range geht)
        for f in c_func_aufrufe:
            f[1].append(-1)
        for f in c_func_namelist:
            f[1].append(-1)
                
        # 3. für jeden Funktionsaufruf wird die zugehörige Knotenabfolge generiert:
        call_counter = 0
        print('c_func_aufrufe',c_func_aufrufe)
        print('c_func_namelist',c_func_namelist)


        #################################################################
        #Neu: Dictionary, welche alle Knotenlisten von Funktionen (bereinigt um die in forbidden enthaltenen und else(=Faalse-If) Knoten) enthält:
        n_pur_dict = {}

        for key in n_ohne_main:
            new_key = key[3:-2]
            n_pur_dict[new_key] = n_ohne_main[key]

            #
                
            temp_value = [x for x in n_pur_dict[new_key] if not any(substring in x for substring in forbidden)]
            print('temp_value',temp_value)
            print('funclist[new_key][1:]',funclist[new_key][1:])
            #print('n_pur_dict',n_pur_dict)
            
            #neu: alle Faalse aus temp_value, die zu elif gehören, werden entfernt
            for i,x in enumerate(funclist[new_key][1:]):
                print(i,'i',x,'x')
                if "_FaalseIf_" in temp_value[i] and "elif" in self.lines_no_dict[x]:
                    print('i',i,'x',x,'temp_value[i]',temp_value[i],'lines_no_dict[x]',self.lines_no_dict[x])
                    del temp_value[i]
                  

            #3c. Zuorndung der Zeilennummern:
            temp_value = [[line,node] for line, node in zip(funclist[new_key][1:], temp_value)]
            #print('temp_value',temp_value)
            #print('n_pur_dict',n_pur_dict)

            #3d. eventuell vorhandenes "else" (id Faalse_If) wird aus n_pur gelöscht.
            temp_value = [x for x in temp_value if "_FaalseIf_" not in x[1]]
            #3e. end-node wird hinzugefügt (nötig für Iteration, damit Vergleich nicht out of range geht)
            temp_value.append(lines_no[-1])
            #print('temp_value',temp_value)
            
            n_pur_dict[new_key] = temp_value
               


        print('n_pur_dict',n_pur_dict)
        #################################################################

        for index, call in enumerate(c_func_aufrufe):
            print('index',index)
            #################################################################
            #Neu - n_pur wird für alle funktionen in einem dict gespeichert
            #3a. Knotenliste der Funktion wird aus n_ohne_main extrahiert:
            for nodelist in n_ohne_main:
                if f"_{call[0]}_" in nodelist:
                #if call[0] in nodelist:
                    n_funclist = n_ohne_main[nodelist]
                    n_funcid = nodelist
                    break
            
            print('n_funcid',n_funcid)
            print('n_funklist',n_funclist)
           
            #################################################################



            #3f. Die Knotenabfolge des Funktionsaufrufs wird generiert:
            n_f_abfolge.clear()
            #func_call_stack = []
            rows = call[1]
            for i in range(1,len(rows)):
                active_func = c_func_namelist[index][1][i-1]
                print('active_func',active_func)
                 
                for k in range(len(n_pur_dict[active_func])):
                    if n_pur_dict[active_func][k][0] == rows[i-1]:
                        print('gefunden',n_pur_dict[active_func][k][0])
                        node1 = n_pur_dict[active_func][k]
                        node2 = n_pur_dict[active_func][k+1]
                        break
                    else:
                        print("error",k)
                print(node1,node2)
                # if f'_Call_{active_func}' in node1[1]:
                #     func_call_stack.append(node1[1])
                #     print('func_call_stack',func_call_stack)
                 ###neu: wegen fehler "UnboundLocalError: local variable 'node1' referenced before assignment"
                if 'node1' in locals():
                    if "_For_" in node1[1] and not rows[i] == node2[0]:
                        n_f_abfolge.append(node1)
                        n_f_abfolge.append([node1[1],node1[1][:2]+"_endFor_"+node1[1][-1]])
                    elif "_IfoEl_" in node1[1] and not rows[i] == node2[0]:
                        n_f_abfolge.append(node1)
                        # n_f_abfolge.append([node1[1],node1[1][:2]+"_e_"+node1[1][-1]])
                        n_f_abfolge.append([node1[1],node1[1][:2]+"_endIfoEl_"+node1[1][-1]])
                    elif "_While_" in node1[1] and not rows[i] == node2[0]:
                        n_f_abfolge.append(node1)
                        # n_f_abfolge.append([node1[1],node1[1][:2]+"_ef_"+node1[1][-1]])
                        n_f_abfolge.append([node1[1],node1[1][:2]+"_endWhile_"+node1[1][-1]])
                    
                    elif "_Break_" in node1[1]:
                        print("break in f entdeckt",node1[1])


                        #Suche rückwärts nach dem nächten While oder For:
                        index_of_break = n_funclist.index(node1[1])
                        for i in range(index_of_break,-1,-1):
                            if "_For_" in n_funclist[i] or "_While_" in n_funclist[i]:
                                end_of_loop = f"{n_funclist[i][:3]}end{n_funclist[i][3:]}"
                                print('end_of_loop_f',end_of_loop)
                                n_f_abfolge.append(node1)
                                n_f_abfolge.append([node1[1],end_of_loop])
                                break

                    elif "_Return_" in node1[1]:
                        print("return in f entdeckt",node1[1], node2[1])

                        if 'end' in node2[1]:
                            n_f_abfolge.append(node1)
                            #n_f_abfolge.append([node1[1],node1[1]])
                        else:
                            #newReturnId = node1[1].replace('_Return_','_Returns_')
                            n_f_abfolge.append(node1+['Returns'])
                            #n_f_abfolge.append([newReturnId,node1[1]])

                    
                    else:
                        n_f_abfolge.append(node1)
                
                print('n_f_abfolge_step(',i,') = ',n_f_abfolge)

    
            print('n_f_abfolge1a',n_f_abfolge)
            n_f_abfolge.insert(0,[n_ohne_main[n_funcid][0],n_ohne_main[n_funcid][0]])
            n_f_abfolge.append([n_ohne_main[n_funcid][-1],n_ohne_main[n_funcid][-1]])

            print('n_f_abfolge1',n_f_abfolge)

            #Neu: Zweiter Call, FuncDef und endFunk der inneren Funktionen werden hinzugefügt:
            func_call_stack = {'funcNo':[n_f_abfolge[0][1][:2]],'funcId':[]}
            #func_call_stack = {'funcNo':[],'funcId':[n_f_abfolge[0][1][:2]+'_Call_'+call[0]+'_'+n_f_abfolge[0][1][1:2]]}
            new_List = n_f_abfolge.copy()
            j = 0
            for i in range(len(n_f_abfolge)-1):
                #print('y=',n_f_abfolge[i][1][8:-2],n_f_abfolge[i][1][8:-2] in funclist.keys())
                # if not n_f_abfolge[i][1][:2] == n_f_abfolge[i+1][1][:2] and not n_f_abfolge[i][1][8:-2] in funclist.keys():
                if n_f_abfolge[i][1][8:-2] in funclist.keys():
                    func_call_stack['funcId'].append(n_f_abfolge[i])
                    func_call_stack['funcNo'].append(n_f_abfolge[i+1][1][:2])

                    new_List.insert(j+1,[func_call_stack['funcNo'][-1]+'_FuncDef_'+func_call_stack['funcNo'][-1][1:2],func_call_stack['funcNo'][-1]+'_FuncDef_'+func_call_stack['funcNo'][-1][1:2]])
                    j += 1
                    #print('func_call_stack',func_call_stack)
                #print(i+1)
                if func_call_stack["funcNo"]:
                    if n_f_abfolge[i+1][1][:2] != func_call_stack["funcNo"][-1]:
                        #print('n_f_abfolge[1][i+1]',n_f_abfolge[i+1][1])
                        new_List.insert(j+1,[func_call_stack['funcNo'][-1]+'_endFunc_'+func_call_stack['funcNo'][-1][1:2],func_call_stack['funcNo'][-1]+'_endFunc_'+func_call_stack['funcNo'][-1][1:2]])
                        j+=1
                        new_List.insert(j+1,func_call_stack["funcId"][-1])
                        #print('newList',new_List)
                        func_call_stack["funcId"].pop()
                        func_call_stack["funcNo"].pop()
                        #print('func_call_stack',func_call_stack)
                        j+=1
                j+=1

                #print('newList_end',new_List)
            #Die restlichen endFunc und Calls vom Stack werden hinzugefügt:
            for i in range(len(func_call_stack["funcId"])):
                #print('func_call_stack',func_call_stack)
                new_List.insert(j,[func_call_stack['funcNo'][-1]+'_endFunc_'+func_call_stack['funcNo'][-1][1:2],func_call_stack['funcNo'][-1]+'_endFunc_'+func_call_stack['funcNo'][-1][1:2]])

                # print('j',j)
                # print('newList',new_List)
                j += 1
                new_List.insert(j,func_call_stack["funcId"][-1])
                j += 1
                func_call_stack["funcId"].pop()
                func_call_stack["funcNo"].pop()
        
 

            n_f_abfolge = new_List

            print('n_f_abfolge1b',n_f_abfolge)

            j = 1
            
            l = len(n_f_abfolge)
            while j < l:
                #print('jl',j,l)
                if j > 100000:
                    js.document.getElementById("values").innerHTML = "<span style='color:red;'>Internal Error - infinite while-Loop in debug, line 650</span>"
                    break
                
                #print('n_funcid',n_funcid)

                for id in self.lineGroups.keys():
                    if n_f_abfolge[j-1][1][:2] == id[:2]:
                        current_funcid = id
                        #print('current_funcid',current_funcid)

                activate = True
                for linepair in self.lineGroups[current_funcid]:
                # for linepair in self.lineGroups[n_funcid]:
                # for linepair in n[1][n_funcid]:
                    #print('linepair',linepair)
                    if n_f_abfolge[j-1][1] == linepair[1] and n_f_abfolge[j][1] == linepair[2] or "_Break_" in n_f_abfolge[j-1][1] or "_Return_" in n_f_abfolge[j-1][1]:
                        activate = False
                        print('yes')
                        break
                
                if activate:
                    for linepair in self.lineGroups[current_funcid]:
                    #for linepair in self.lineGroups[n_funcid]:
                    # for linepair in n[1][n_funcid]:
                        #if linepair[1] == n_f_abfolge[j-1][1]:
                
                        if linepair[1] == n_f_abfolge[j-1][1] and n_f_abfolge[j-1][1][:2] == n_f_abfolge[j][1][:2]:
                            n_f_abfolge.insert(j,[linepair[2],linepair[2]])
                            print('n_f_abfolge_neu!',n_f_abfolge)
                            l += 1
                            break
                j += 1

            print("n_f_abfolge2",n_f_abfolge)
            #print(n_call_index[call_counter],n_abfolge[n_call_index[call_counter]])

            #3g. Die Knotenabfolge wird in n_abfolge beim zugehörigen Call eingefügt.Vorher wird der Call-Knoten verdoppelt:
            n_abfolge.insert(n_call_index[call_counter],n_abfolge[n_call_index[call_counter]])

        
            for i in range(len(n_f_abfolge)):
                n_abfolge.insert(n_call_index[call_counter]+1+i,n_f_abfolge[i])
            call_counter += 1
            #3f.Abfangen der Verschiebung der Call-Positionen durch das Einsetzen der Funktionsabfolge:
            for i in range(call_counter,len(n_call_index)):
                n_call_index[i] += len(n_f_abfolge) + 1
            
            print('n_abfolge3',n_abfolge)
            
        #4. Aus lineGroups (=n[1]) alle lines in ein array copieren (ohne einer group zugeordnet zu sein):
        raw_lines = [element for list in self.lineGroups.values() for element in list]
        #raw_lines = [element for list in n[1].values() for element in list]
        
        # n_abfolge wird als letztes Element error_message hinzugefügt:
        n_abfolge.append([f"{type(error_message).__name__}:",f"{str(error_message)}"])


        ### C. Zeilen der Funktionsdefinitionen werden n_abfolge hinzugefügt: ###
        #########################################################################
        # Setze bei allen Listen in n_abfolge ein drittes Listenelement 0, damit highlighter diese von den funcdefs unterscheiden kann
        
        # print('nodes1',n_abfolge)
        n_abfolge_uni = []
        [n_abfolge_uni.append(element) for element in n_abfolge if element not in n_abfolge_uni]

        for nodes in n_abfolge_uni:
            if len(nodes) == 2:
                nodes.append(0)

        # Füge funcdefs in n_abfolge ein:
        # 1. Liste der funDefs generieren:
        funcDefs = [[funclist[i][0],f"d_{i}_",1] for i in funclist]
        # 2. rows_origin um -1 ergänzen:
        rows4funcDefs = rows_origin.copy()
        rows4funcDefs.append(-1)
        rowsOfNodes = {node[0] for node in n_abfolge if isinstance(node[0],int)}
        # print('rowsOfNodes',rowsOfNodes)
        # print('rows4funcDefs',rows4funcDefs)
        # print('funcDefs',funcDefs)
        # print('nodes2',n_abfolge)
        rowAfterfuncDef = None
        # 3. funcDefs werden in n_abfolge eingefügt:
        for funcdef in funcDefs:
            for i in range(rows4funcDefs.index(funcdef[0])+1,len(rows4funcDefs)):
                if rows4funcDefs[i] in rowsOfNodes:
                    rowAfterfuncDef = rows4funcDefs[i]
                    break
            #rowAfterfuncDef = rows4funcDefs[rows4funcDefs.index(funcdef[0])+1]
            #rowAfterfuncDef = next((element[0] for element in n_abfolge if element[0] == funcdef[0]), None)
            #print('rowAfterfuncDef',rowAfterfuncDef)
            if rowAfterfuncDef != -1:
                
                place2insert = next((index for index, element in enumerate(n_abfolge) if element[0] == rowAfterfuncDef), None)
                #print('place2insert',place2insert)
                n_abfolge.insert(place2insert,funcdef)
            
            else:
                place2insert = next((index for index, element in enumerate(n_abfolge) if element[0] == 'Stop'), None)
                #print('place2insert',place2insert)
                n_abfolge.insert(place2insert,funcdef)



        #Generiere Abfolge von outputs:
        out = 0
        for node in n_abfolge:
            if node[0] in self.lineno_print:
                self.stout_abfolge.append([node[0],tracer[4][out]])
                out += 1
            elif isinstance(node[0],str) and 'Error' in node[0]:
                self.stout_abfolge.append([node[0],node[1]])
            else:
                self.stout_abfolge.append([node[0],None])
        print('stout_abfolge',self.stout_abfolge)
        
        
        print('n_abfolge',n_abfolge)
        print('raw_lines',raw_lines)
        print(error_message)
        #print(n_abfolge[-1])
        #print('lineGroups',n[1])
        return n_abfolge, raw_lines, self.stout_abfolge
        #return n_abfolge, raw_lines, self.stout_abfolge, self.stoutList, self.sterror, self.sterror_lineno #, n
    
