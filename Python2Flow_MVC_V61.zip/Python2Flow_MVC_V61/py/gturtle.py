def makeTurtle():
    pass
def hideTurtle():
    pass
def ht():
    pass
def showTurtle():
    pass
def st():
    pass

def forward(x):
    pass
def fd(x):
    pass
def back(x):
    pass
def backward(x):
    pass
def bk(x):
    pass
def right(x):
    pass
def rt(x):
    pass
def left(x):
    pass
def lt(x):
    pass
...
def setPenColor(x):
    pass

def spc(x):
    pass
def setPenWidth(x):
    pass
def spw(x):
    pass
def setLineWidth(x):
    pass
def delay(x):
    pass
def speed(x):
    pass
def penUp():
    pass
def pu():
    pass
def penDown():
    pass
def pd():
    pass
def dot(x):
    pass
def setHeading(x):
    pass
def heading(x=None):
    pass
# def heading():
#     pass
def setRandomHeading():
    pass
def leftCircle(x):
    pass
def rightCircle(x):
    pass
def leftArc(x,y):
    pass
def rightArc(x,y):
    pass
def msgDlg(x):
    pass
def label(x):
    pass
def setFillColor(x):
    pass
def setColor(x):
    pass
def startPath():
    pass
def fillPath():
    pass
def sqrt(x):
    pass
def isInteger(x):
    pass
def makeColor(x):
    pass
def makeColor(r,g,b):
    pass
def makeColor(r,g,b,a):
    pass
def makeColor(x,y):
    pass
def getPixelColor():
    pass
def getKey():
    pass
def gerKeyCode():
    pass
def getPos():
    pass
def getX():
    pass
def getY():
    pass
def setX(x):
    pass
def setY(y):
    pass
def distance(x,y):
    pass
def towards(x,y):
    pass
def moveTo(x,y):
    pass
def setPos(x,y):
    pass
def clean():
    pass
def clearScreen():
    pass
def cs():
    pass
def clear():
    pass
def savePlayground():
    pass
