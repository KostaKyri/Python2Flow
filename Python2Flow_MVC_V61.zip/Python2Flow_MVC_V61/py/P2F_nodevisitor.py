from _ast import AST, FunctionDef
import ast
from typing import Any


class Node:
    def __init__(self,):
        self.values = {}


class FuncDefVisitor(ast.NodeVisitor):

    def __init__(self):
        self.DefCalls = []
    
    def visit_FunctionDef(self, node):
        self.DefCalls.append(node.name)
        self.generic_visit(node)
    

class P2FNodeVisitor(ast.NodeVisitor):
    
    def __init__(self,id_praefix = "m0"):
        self.id_praefix = id_praefix
        self.a_counter = 0
        self.ex_counter = 0
        self.c_counter = 0
        self.if_counter = 0
        self.for_counter = 0
        self.while_counter = 0
        self.func_counter = 0
        self.return_counter = 0
        self.break_counter = 0
        self.continue_counter = 0

        self.node_idlist = []
        self.node_ids = {"m_Start_":self.node_idlist}
        self.box = ["Ifbox","IfElbox","Whilebox","Funcbox","Forbox"]
        self.line_no = []


        self.main_tree = []
        self.func_trees = []

        self.defCalls = []

        Main = Node()
        Main.values.update({'id':'main', 'class':'Main'})
        self.main_tree.append(Main)
    
    # ================
    # Top level nodes:
    # ================   
    def visit_Module(self, node):

        #Generiert eine Liste aller Funktionsnamen, welche im code definiert wurden
        defcallvis = FuncDefVisitor()
        for i in node.body:
              defcallvis.visit(i)
        
        self.defCalls = defcallvis.DefCalls
        print('defcallvis',self.defCalls)


        Start = Node()
        Start.values.update({'value':'Start', 'id':f'{self.id_praefix}_Start_', 'class':'Terminal'})
        self.main_tree.append([Start])
        self.node_idlist.append(Start.values['id'])

        
        for i in node.body:
            if not isinstance(i, ast.FunctionDef):
                child = self.visit(i)
                self.main_tree.append(child)
            else:
                child = self.visit(i)
                self.func_trees.append(child)
                    
        # for i in self.func_trees:
        #     print('func_tree',i)


        Stop = Node()
        Stop.values.update({'value':'Stop', 'id':f'{self.id_praefix}_Stop_', 'class':'Terminal'})
        self.main_tree.append([Stop])
        self.node_idlist.append(Stop.values['id'])


    # ============
    # Control flow:
    # ============ 
    def visit_If(self,node):
        #print('line',node.lineno)
        #print('lineEnd',node.end_lineno)
        #print('else',node.orelse[0].lineno-1)
        # if node.orelse[0].__class__.__name__ == "If":
        #     print("Ja")
        # else:
        #     print("Nein")
        #print('node',node.orelse[0].__class__.__name__)
        IF = []
        if bool(node.orelse):
            Ifbox = Node()
            Ifbox.values.update({'id':f'{self.id_praefix}_IfElbox_{self.if_counter}', 'class':'IfElbox'})
            If = Node()
            If.values.update({'id':f'{self.id_praefix}_IfEl_{self.if_counter}', 'class':'If'})
        else:
            Ifbox = Node()
            Ifbox.values.update({'id':f'{self.id_praefix}_Ifbox_{self.if_counter}', 'class':'Ifbox'})
            If = Node()
            If.values.update({'id':f'{self.id_praefix}_IfoEl_{self.if_counter}', 'class':'If'})

        IF.append(Ifbox)
        IF.append([If])


        test = self.visit(node.test)
        If.values.update({'value':f"if {test}:"})
        If.values.update({'lineno':node.lineno})


    
        self.node_idlist.append(If.values['id'])
        self.line_no.append([If.values['id'],node.lineno])
        temp_if_counter = self.if_counter
        self.if_counter += 1

        TrueBox = Node()
        TrueBox.values.update({'id':f'{self.id_praefix}_TrueIf_{temp_if_counter}', 'class':'True'})
        TrueList = [TrueBox]
        IF.append(TrueList)

        self.node_idlist.append(TrueBox.values['id'])
        
        for i in node.body:
            child_true = self.visit(i)
            TrueList.append(child_true)
        

        FalseBox = Node()
        if bool(node.orelse):
            FalseBox.values.update({'id':f'{self.id_praefix}_FaalseIf_{temp_if_counter}', 'class':'False'})
        else:
            FalseBox.values.update({'id':f'{self.id_praefix}_FalseIf_{temp_if_counter}', 'class':'False'})

        FalseList = [FalseBox]
        IF.append(FalseList)
        self.node_idlist.append(FalseBox.values['id'])

        if bool(node.orelse):
            for i in node.orelse:
                child_false = self.visit(i)
                FalseList.append(child_false)
        else:
            E = Node()
            E.values.update({'id':f'{self.id_praefix}_e_{temp_if_counter}', 'class':'e'})
            FalseList.append([E])
            self.node_idlist.append(E.values['id'])
        
        endIf = Node()
        if bool(node.orelse):
            
            endIf.values.update({'id':f'{self.id_praefix}_endIfEl_{temp_if_counter}', 'class':'endIf'})
        else:
            endIf.values.update({'id':f'{self.id_praefix}_endIfoEl_{temp_if_counter}', 'class':'endIf'})

        IF.append([endIf])
        self.node_idlist.append(endIf.values['id'])
        
        return IF
    
    def visit_For(self,node):
        FOR = []
        Forbox = Node()
        Forbox.values.update({'id':f'{self.id_praefix}_Forbox_{self.for_counter}', 'class':'Forbox'})
        
        FOR.append(Forbox)
        

        target = self.visit(node.target)
        iter = self.visit(node.iter)
        
        For = Node()
        For.values.update({'id':f'{self.id_praefix}_For_{self.for_counter}', 'class':'For'})
        FOR.append([For])
        For.values.update({'value':f"for {target} in {iter}:"})
        For.values.update({'lineno':node.lineno})

        self.node_idlist.append(For.values['id'])

        temp_for_counter = self.for_counter
        self.for_counter += 1
        
        NextBox = Node()
        NextBox.values.update({'id':f'{self.id_praefix}_Next_{temp_for_counter}', 'class':'Next'})
        NextList = [NextBox]
        FOR.append(NextList)
        self.node_idlist.append(NextBox.values['id'])
        
        for i in node.body:
            child_next = self.visit(i)
            NextList.append(child_next)

        endFor = Node()
        endFor.values.update({'id':f'{self.id_praefix}_endFor_{temp_for_counter}', 'class':'endFor'})
        FOR.append([endFor])
        self.node_idlist.append(endFor.values['id'])
        
        return FOR
    
    
    def visit_While(self,node):
        WHILE = []
        Whilebox = Node()
        Whilebox.values.update({'id':f'{self.id_praefix}_Whilebox_{self.while_counter}', 'class':'Whilebox'})
        While = Node()
        While.values.update({'id':f'{self.id_praefix}_While_{self.while_counter}', 'class':'While'})

        WHILE.append(Whilebox)
        WHILE.append([While])

        test = self.visit(node.test)
        While.values.update({'value':f"while {test}:"})
        While.values.update({'lineno':node.lineno})

    
        self.node_idlist.append(While.values['id'])
        temp_while_counter = self.while_counter
        self.while_counter += 1
        
    
        TrueBox = Node()
        TrueBox.values.update({'id':f'{self.id_praefix}_TruW_{temp_while_counter}', 'class':'True'})
        TrueList = [TrueBox]
        WHILE.append(TrueList)
        self.node_idlist.append(TrueBox.values['id'])
        
        for i in node.body:
            child_true = self.visit(i)
            TrueList.append(child_true)

        FalseBox = Node()
        FalseBox.values.update({'id':f'{self.id_praefix}_FalsW_{temp_while_counter}', 'class':'False'})
  
        FalseList = [FalseBox]
        WHILE.append(FalseList)
        self.node_idlist.append(FalseBox.values['id'])

        ef = Node()
        ef.values.update({'id':f'{self.id_praefix}_ef_{temp_while_counter}', 'class':'e'})
        FalseList.append([ef])
        self.node_idlist.append(ef.values['id'])
        
        BackLoopBox = Node()
        BackLoopBox.values.update({'id':f'{self.id_praefix}_backLoop_{temp_while_counter}', 'class':'backLoop'})
        BackLoopList = [BackLoopBox]
        WHILE.append(BackLoopList)
        self.node_idlist.append(BackLoopBox.values['id'])

        el = Node()
        el.values.update({'id':f'{self.id_praefix}_el_{temp_while_counter}', 'class':'e'})
        BackLoopList.append([el])
        self.node_idlist.append(el.values['id'])
        
        endWhile = Node()
        endWhile.values.update({'id':f'{self.id_praefix}_endWhile_{temp_while_counter}', 'class':'endWhile'})
        WHILE.append([endWhile])
        self.node_idlist.append(endWhile.values['id'])
        
        return WHILE
    
    def visit_Break(self,node):
        BREAK = []
        Break = Node()
        Break.values.update({'id':f'{self.id_praefix}_Break_{self.break_counter}', 'class':'Assign'})
        BREAK.append(Break)
        Break.values.update({'value':f"break"})
        Break.values.update({'lineno':node.lineno})

        self.node_idlist.append(Break.values['id'])
        self.break_counter += 1
        return BREAK


    def visit_Continue(self,node):
        CONTINUE = []
        Continue = Node()
        Continue.values.update({'id':f'{self.id_praefix}_Continue_{self.continue_counter}', 'class':'Assign'})
        CONTINUE.append(Continue)
        Continue.values.update({'value':f"continue"})
        Continue.values.update({'lineno':node.lineno})

        self.node_idlist.append(Continue.values['id'])
        self.continue_counter += 1
        return CONTINUE

    # #def visit_Try(self,node):
    # #def visit_TryFinally(self,node):
    # #def visit_TryExcept(self,node):
    # #def visit_ExceptHandler(self,node):
    # #def visit_With(self,node):
    # #def visit_withitem(self,node):
    
    # ==============================
    # Function an class definitions:
    # ==============================
    def visit_FunctionDef(self, node):
        FUNC = []
        Funcbox = Node()
        Funcbox.values.update({'id':f'f{self.func_counter}_{node.name}_{self.func_counter}', 'class':'Funcbox'})
        Func = Node()
        Func.values.update({'id':f'f{self.func_counter}_FuncDef_{self.func_counter}', 'class':'FuncDef'})

        FUNC.append(Funcbox)
        FUNC.append([Func])

        self.node_ids[Funcbox.values['id']]=[Func.values['id']]
        # Decorators vorerst noch nicht in Flussdiagramm eingebaut.
        decorator_list = []
        for i in node.decorator_list:
            decorator_list.append(self.visit(i))
        
        name = node.name
        args = self.visit(node.args)

        Func.values.update({'value':f"{name}({args})"})
        Func.values.update({'lineno':node.lineno})
       
        Funcbody = Node()
        Funcbody.values.update({'id':f'f{self.func_counter}_Funcbody_', 'class':'Funcbody'})
        FuncList = [Funcbody]
        FUNC.append(FuncList)

        
        funcvis = P2FNodeVisitor(f"f{self.func_counter}")
        funcvis.node_ids = self.node_ids
        funcvis.defCalls = self.defCalls
        
        for i in node.body:
            child_func = funcvis.visit(i)
            FuncList.append(child_func)
        self.node_ids[Funcbox.values['id']] += funcvis.node_idlist

        
        endFunc = Node()
        endFunc.values.update({'id':f'f{self.func_counter}_endFunc_{self.func_counter}', 'class':'endFunc'})
        FUNC.append([endFunc])
        self.node_ids[Funcbox.values['id']].append(endFunc.values['id'])

        self.func_counter += 1

        return FUNC
    
    # def visit_Lambda(self,node):
    
    def visit_arguments(self,node):
        arguments = []
        # for a in node.posonlyargs:
        #     arguments.append(f"{self.visit(a)}")
        # if node.posonlyargs != None:
        #     arguments.append("/")
        for a in node.args:
            arguments.append(f"{self.visit(a)}")
        # vararg, kwonlyargs, kw_defaults, kwarg, defaults noch nicht implementiert
        arguments_str = ""
        if len(arguments) == 1:
            arguments_str += f"{arguments[0]}"
        elif len(arguments) > 1:
            arguments_str += f"{arguments[0]}"
            for a in range(1,len(arguments)):
                arguments_str += f", {arguments[a]}"
        else:
            pass
        return arguments_str
        
    def visit_arg(self,node):
        if node.annotation == None:
            return f"{node.arg}"
        else:
            return f"{node.arg}: {self.visit(node.annotation)}"
        
    def visit_Return(self,node):
        RETURN = []
        #value = self.visit(node.value)
        #Expression-Knoten setzen:
        Return = Node()
        RETURN.append(Return)

        if node.value != None:
            value = self.visit(node.value)
            #test, ob es sich um eine definierte Funktion handelt (aber keine externe):
            test = str(node.value.func.id) in self.defCalls if (isinstance(node.value.func,ast.Call) and not isinstance(node.value,ast.Attribute)) else False
            #print("return",str(node.value.func.id))
            if test:
                Return.values.update({'id':f'{self.id_praefix}_Call_{node.value.func.id}_{self.c_counter}', 'class':'DefCallReturn'})
                self.c_counter += 1
            else:
                Return.values.update({'id':f'{self.id_praefix}_Return_{self.return_counter}', 'class':'Expression'})


            #Return.values.update({'id':f'{self.id_praefix}_Return_{self.return_counter}', 'class':'Expression'})

            # Return.values.update({'id':f'f{self.func_counter}_Return_{self.func_counter}', 'class':'Expression'})
            self.node_idlist.append(Return.values['id'])
            Return.values['value'] = f"return {value}"
        else:
            Return.values.update({'id':f'{self.id_praefix}_Return_{self.return_counter}', 'class':'Expression'})
            self.node_idlist.append(Return.values['id'])
            Return.values['value'] = f"return"
        
        Return.values.update({'lineno':node.lineno})

        self.return_counter += 1
        return RETURN
    
    # # def visit_Yield(self,node):
    # # def visit_YieldFrom(self,node):
    # # def visit_Global(self,node):
    # # def visit_Nonlocal(self,node):
    # # def visit_ClassDef(self,node):
    
    # # ================
    # # Async and await:
    # # ================
    def visit_AsyncFunctionDef(self,node):
        FUNC = []
        Funcbox = Node()
        Funcbox.values.update({'id':f'f{self.func_counter}_{node.name}_{self.func_counter}', 'class':'Funcbox'})
        Func = Node()
        Func.values.update({'id':f'f{self.func_counter}_FuncDef_{self.func_counter}', 'class':'FuncDef'})

        FUNC.append(Funcbox)
        FUNC.append([Func])

        self.node_ids[Funcbox.values['id']]=[Func.values['id']]
        # Decorators vorerst noch nicht in Flussdiagramm eingebaut.
        decorator_list = []
        for i in node.decorator_list:
            decorator_list.append(self.visit(i))
        
        name = node.name
        args = self.visit(node.args)

        Func.values.update({'value':f"{name}({args})"})
        Func.values.update({'lineno':node.lineno})
       
        Funcbody = Node()
        Funcbody.values.update({'id':f'f{self.func_counter}_Funcbody_', 'class':'Funcbody'})
        FuncList = [Funcbody]
        FUNC.append(FuncList)

        
        funcvis = P2FNodeVisitor(f"f{self.func_counter}")
        funcvis.node_ids = self.node_ids
        funcvis.defCalls = self.defCalls

        
        for i in node.body:
            child_func = funcvis.visit(i)
            FuncList.append(child_func)
        self.node_ids[Funcbox.values['id']] += funcvis.node_idlist

        
        endFunc = Node()
        endFunc.values.update({'id':f'f{self.func_counter}_endFunc_{self.func_counter}', 'class':'endFunc'})
        FUNC.append([endFunc])
        self.node_ids[Funcbox.values['id']].append(endFunc.values['id'])

        self.func_counter += 1

        return FUNC
    
    def visit_Await(self,node):
        EXPR = []
        value = self.visit(node.value)
        #Expression-Knoten setzen:
        Expr = Node()
        EXPR.append(Expr)

        # Test, ob es ein selbstdefinierter Funktionsaufruf ist:
        #neu:
        test = str(node.value.func.id) in self.defCalls 
        #print('test',node.value.func.id,test, self.defCalls)

        #alt:
        # test = False
        # for key in self.node_ids.keys():
        #     if f'_{node.value.func.id}_' in key:
        #         test = True

        if isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Name):
            if node.value.func.id == 'print':
                Expr.values.update({'id':f'{self.id_praefix}_Call_{node.value.func.id}_{self.ex_counter}', 'class':'IO'})
            elif test:
                Expr.values.update({'id':f'{self.id_praefix}_Call_{node.value.func.id}_{self.c_counter}', 'class':'DefCall'})
                self.c_counter += 1
            else:
                Expr.values.update({'id':f'{self.id_praefix}_Call_{node.value.func.id}_{self.ex_counter}', 'class':'Call'})


        elif isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute):
            Expr.values.update({'id':f'{self.id_praefix}_Call_{node.value.func.value.id}.{node.value.func.attr}_{self.ex_counter}', 'class':'Call'})
        else:
            Expr.values.update({'id':f'{self.id_praefix}_Expression_{self.ex_counter}', 'class':'Expression'})
        Expr.values['value'] = f"{value}"
        self.node_idlist.append(Expr.values['id'])

        Expr.values.update({'lineno':node.lineno})

        self.ex_counter += 1
        return EXPR

    # #def visit_AsyncFor(self,node):
    # #def visit_AsyncWith(self,node):

    # # =========
    # # Literals:
    # # =========
    def visit_Constant(self,node):
        if isinstance(node.value ,str):
            return f'"{node.value}"'
        else:
            return f'{node.value}'
    # visit_FormattedValue
    # visit_JoinedStr
    def visit_List(self,node):
        if len(node.elts) == 0:
            return f"[]"
        else:
            elts = f"["
            for i in range(0,len(node.elts)-1):
                elts += f"{self.visit(node.elts[i])}, "
            elts += f"{self.visit(node.elts[-1])}]"
            return elts
    def visit_Tuple(self,node):
        if len(node.elts) == 0:
            return f"()"
        else:
            elts = f"("
            for i in range(0,len(node.elts)-1):
                elts += f"{self.visit(node.elts[i])}, "
            elts += f"{self.visit(node.elts[-1])})"
            return elts
    def visit_Set(self,node):
        if len(node.elts) == 0:
            return f"{{}}"
        else:
            elts = f"{{"
            for i in range(0,len(node.elts)-1):
                elts += f"{self.visit(node.elts[i])}, "
            elts += f"{self.visit(node.elts[-1])}}}"
            return elts
    def visit_Dict(self,node):
        if len(node.keys) == 0:
            return f"{{}}"
        else:
            elts = f"{{"
            for i in range(0,len(node.keys)-1):
                elts += f"{self.visit(node.keys[i])}: {self.visit(node.values[i])}, "
            elts += f"{self.visit(node.keys[-1])}: {self.visit(node.values[-1])}}}"
            return elts
    # visit_NameConstant

    # ==========
    # Variables:
    # ==========
    def visit_Name(self,node):
        return f"{node.id}"
    
    def visit_Load(self,node):
        pass
    def visit_Store(self,node):
        pass
    def visit_DEl(self,node):
        pass
    
    def visit_Starred(self,node):
        return f"*{self.visit(node.value)}"
    
    # ============
    # Expressions:
    # ============
    def visit_Expr(self,node):
        EXPR = []
        value = self.visit(node.value)
        #Expression-Knoten setzen:
        Expr = Node()
        EXPR.append(Expr)

        # Test, ob es ein selbstdefinierter Funktionsaufruf ist:
        #neu:
        if isinstance(node.value, ast.Call) and not isinstance(node.value.func,ast.Attribute):
            test = str(node.value.func.id) in self.defCalls
        else:
            test = False
        #print('test',node.value.func.id,test, self.defCalls)

        #alt:
        # test = False
        # for key in self.node_ids.keys():
        #     if f'_{node.value.func.id}_' in key:
        #         test = True

        if isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Name):
            if node.value.func.id == 'print':
                test = str(node.value.args[0].func.id) in self.defCalls if (isinstance(node.value.args[0],ast.Call) and not isinstance(node.value.args[0].func,ast.Attribute)) else False
                if test:
                    Expr.values.update({'id':f'{self.id_praefix}_Call_{node.value.args[0].func.id}_{self.c_counter}', 'class':'DefCallIO'})
                    self.c_counter += 1
                else:
                    Expr.values.update({'id':f'{self.id_praefix}_Call_{node.value.func.id}_{self.ex_counter}', 'class':'IO'})
            elif test:
                Expr.values.update({'id':f'{self.id_praefix}_Call_{node.value.func.id}_{self.c_counter}', 'class':'DefCall'})
                self.c_counter += 1
            else:
                Expr.values.update({'id':f'{self.id_praefix}_Call_{node.value.func.id}_{self.ex_counter}', 'class':'Call'})


        elif isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute):
            Expr.values.update({'id':f'{self.id_praefix}_Call_{node.value.func.value.id}.{node.value.func.attr}_{self.ex_counter}', 'class':'Call'})
        else:
            Expr.values.update({'id':f'{self.id_praefix}_Expression_{self.ex_counter}', 'class':'Expression'})
        Expr.values['value'] = f"{value}"
        self.node_idlist.append(Expr.values['id'])

        Expr.values.update({'lineno':node.lineno})

        self.ex_counter += 1
        return EXPR

    def visit_NamedExpr(self,node):
        target = self.visit(node.target)
        value = self.visit(node.value)
        return f"{target} := {value}"
    
    def visit_UnaryOp(self,node):
        op = self.visit(node.op)
        operand = self.visit(node.operand)
        return f"{op}{operand}"
    def visit_UAdd(self,node):
        return f"+"
    def visit_USub(self,node):
        return f"-"
    def visit_Not(self,node):
        return f"not "
    def visit_Invert(self,node):
        return f"~"
    
    def visit_BinOp(self,node):
        left = self.visit(node.left)
        op = self.visit(node.op)
        right = self.visit(node.right)
        return f"{left} {op} {right}"
    
    def visit_Add(self,node):
        return f"+"
    def visit_Sub(self,node):
        return f"-"
    def visit_Mult(self,node):
        return f"*"
    def visit_Div(self,node):
        return f"/"
    def visit_FloorDiv(self,node):
        return f"//"
    def visit_Mod(self,node):
        return f"%"
    def visit_Pow(self,node):
        return f"**"
    def visit_LShift(self,node):
        return f"<<"
    def visit_RShift(self,node):
        return f">>"
    def visit_BitOr(self,node):
        return f"|"
    def visit_BitXor(self,node):
        return f"^"
    def visit_BitAnd(self,node):
        return f"&"
    def visit_MatMult(self,node):
        return f"@"
    
    def visit_BoolOp(self,node):
        op = self.visit(node.op)
        left = f"{self.visit(node.values[0])}"
        right = f"{self.visit(node.values[1])}"
        return f"{left} {op} {right}"
    
    def visit_And(self,node):
        return f"and"
    def visit_Or(self,node):
        return f"or"
    
    def visit_Compare(self,node):
        left = self.visit(node.left)
        op = self.visit(node.ops[0])
        right = self.visit(node.comparators[0])
        return f"{left} {op} {right}"

    def visit_Eq(self,node):
        return f"=="
    def visit_NotEq(sself,nodeelf):
        return f"!="
    def visit_Lt(self,node):
        return f"<"
    def visit_LtE(self,node):
        return f"<="
    def visit_Gt(self,node):
        return f">"
    def visit_GtE(self,node):
        return f">="
    def visit_Is(self,node):
        return f"is"
    def visit_IsNot(self,node):
        return f"is not"
    def visit_In(self,node):
        return f"in"
    def visit_NotIn(self,node):
        return f"not in"
    
    def visit_Call(self,node):
        func = self.visit(node.func)
        arglist = []
        for i in node.args:
            arglist.append(self.visit(i))
        for i in node.keywords:
            arglist.append(self.visit(i))
        # Anmerkung: staatgs & kwargs ab Python 3.5 entfernt
        arglist_str = ""
        if len(arglist) == 0:
            return f"{func}({arglist_str})"
        elif len(arglist) == 1:
            return f"{func}({arglist[0]})"
        else:
            arglist_str += f"{arglist[0]}"
            for i in range(1,len(arglist)):
                arglist_str += f", {arglist[i]}"
            return f"{func}({arglist_str})"
    
    def visit_keyword(self,node):
        if node.arg == None:
            return f"**{self.visit(node.value)}"
        else:
            return f"{node.arg} = {self.visit(node.value)}"
    
    def visit_IfExp(self,node):
        test = self.visit(node.test)
        body = self.visit(node.body)
        orelse = self.visit(node.orelse)
        return f"{body} if {test} else {orelse}"
    
    def visit_Attribute(self,node):
        value = self.visit(node.value)
        attr = f'{node.attr}'
        #attr = self.visit(node.attr)
        return f"{value}.{attr}"
    
    # =============
    # Subscripting:
    # =============
    def visit_Subscript(self, node):
        value = self.visit(node.value)
        slice = self.visit(node.slice)
        return f"{value}[{slice}]"
    
    def visit_Index(self,node):
        value = self.visit(node.value)
        return f"{value}"
    
    def visit_Slice(self,node):
        if node.lower == None:
            lower = ""
        else:
            lower = self.visit(node.lower)
        if node.upper == None:
            upper = ""
        else:
            upper = self.visit(node.upper)
        if node.step == None:
            return f"{lower}:{upper}"
        else:
            step = self.visit(node.step)
            return f"{lower}:{upper}:{step}"
    
    # def visit_ExtSlice(self, node):
    #     dim = f"{self.visit(node.dims[0])}"
    #     for i in range(1,len(node.dims)):
    #         dim += f",{self.visit(node.dims[i])}"
    #     return dim
    
    # ===============
    # Comprehensions:
    # ===============
    
    
    # ===========
    # Statements:
    # ===========
    def visit_Assign(self, node):
        ASSIGN = []
        target = f""
        for i in node.targets:
            target += f"{self.visit(i)} = "
        value = self.visit(node.value)

        Assign = Node()
        ASSIGN.append(Assign)

        if isinstance(node.value, ast.Call) and not isinstance(node.value.func,ast.Attribute):
            test = str(node.value.func.id) in self.defCalls

            if test:
                Assign.values.update({'id':f'{self.id_praefix}_Call_{node.value.func.id}_{self.c_counter}', 'class':'DefCallAssign'})
                self.c_counter += 1
            elif node.value.func.id == 'input' or (node.value.func.id in ['int','float'] and node.value.args[0].func.id == 'input'):
                Assign.values.update({'id':f'{self.id_praefix}_Assign_{self.a_counter}', 'class':'AssignIO'})
            else:
                Assign.values.update({'id':f'{self.id_praefix}_Assign_{self.a_counter}', 'class':'Assign'})

        else:
            Assign.values.update({'id':f'{self.id_praefix}_Assign_{self.a_counter}', 'class':'Assign'})
        Assign.values['value'] = f"{target}{value}"
        self.node_idlist.append(Assign.values['id'])

        Assign.values.update({'lineno':node.lineno})

        self.a_counter += 1
        return ASSIGN
    
    #visit_AnnAssign  
    def visit_AugAssign(self, node):
        AUGASSIGN = []
        target = self.visit(node.target)
        op = self.visit(node.op)
        value = self.visit(node.value)
        AugAssign = Node()
        AUGASSIGN.append(AugAssign)

        if isinstance(node.value, ast.Call) and not isinstance(node.value.func,ast.Attribute):
            test = str(node.value.func.id) in self.defCalls

            if test:
                AugAssign.values.update({'id':f'{self.id_praefix}_Call_{node.value.func.id}_{self.a_counter}', 'class':'DefCallAssign'})
            else:
                AugAssign.values.update({'id':f'{self.id_praefix}_Assign_{self.a_counter}', 'class':'Assign'})

        else:
            AugAssign.values.update({'id':f'{self.id_praefix}_Assign_{self.a_counter}', 'class':'Assign'})
        AugAssign.values['value'] = f"{target} {op}= {value}"
        # div_augassign = div_generator("div","Assign","Assign",self.id_praefix,self.a_counter)
        # div_augassign.innerHTML = f"{target} {op}= {value}"
        self.node_idlist.append(AugAssign.values['id'])

        AugAssign.values.update({'lineno':node.lineno})
        self.a_counter += 1
        return AUGASSIGN
    
    # # visit_Raise
    # # visit_Assert
    # def visit_Delete(self,node):
    #     targets_list = []
    #     for i in node.targets:
    #         targets_list.append(self.visit(i))
    #     targets = f""
    #     if len(targets_list) == 1:
    #         targets += f"{targets_list[0]}"
    #     else:
    #         targets += f"{targets_list[0]}"
    #         for i in range(1,len(targets_list)):
    #             targets += f", {targets_list[i]}"
    #     div_del = div_generator("div","Assign","Assign",self.id_praefix,self.a_counter)
    #     div_del.innerHTML = f"del {targets}"
    #     self.node_idlist.append(div_del.id)

    #     self.a_counter += 1
    #     return div_del

    def visit_Pass(self,node):
        PASS = []
        Pass = Node()
        PASS.append(Pass)
        Pass.values.update({'id':f'{self.id_praefix}_Pass_{self.a_counter}', 'class':'Assign'})
        Pass.values['value'] = f"pass"
        self.node_idlist.append(Pass.values['id'])

        Pass.values.update({'lineno':node.lineno})

        self.a_counter += 1

        return PASS


    # ========
    # Imports:
    # ========
    def visit_Import(self,node):
        IMPORT = []
        names_list = []
        for i in node.names:
            #print('sdsd',self.visit(i))
            names_list.append(self.visit(i))
        names = f""
        if len(names_list) == 1:
            names += f"{names_list[0]}"
        else:
            names += f"{names_list[0]}"
            for i in range(1,len(names_list)):
                names += f", {names_list[i]}"
        #print('names',names_list)
        Import = Node()
        IMPORT.append(Import)
        Import.values.update({'id':f'{self.id_praefix}_Assign_{self.a_counter}', 'class':'Assign'})
        Import.values['value'] = f"import {names}"
        Import.values.update({'lineno':node.lineno})
        # div_imp = div_generator("div","Assign","Assign",self.id_praefix,self.a_counter)
        # div_imp.innerHTML = f"import {names}"
        self.node_idlist.append(Import.values['id'])

        self.a_counter += 1
        return IMPORT

    def visit_ImportFrom(self,node):
        IMPORTFROM =[]
        module = f""
        for dots in range(0,node.level):
            module += "."
        module += node.module
        names_list = []
        for i in node.names:
            names_list.append(self.visit(i))
        names = f""
        if len(names_list) == 1:
            names += f"{names_list[0]}"
        else:
            names += f"{names_list[0]}"
            for i in range(1,len(names_list)):
                names += f", {names_list[i]}"
        Importfrom = Node()
        IMPORTFROM.append(Importfrom)
        Importfrom.values.update({'id':f'{self.id_praefix}_Assign_{self.a_counter}', 'class':'Assign'})
        Importfrom.values['value'] = f"from {module} import {names}"
        Importfrom.values.update({'lineno':node.lineno})
        # div_impfr = div_generator("div","Assign","Assign",self.id_praefix,self.a_counter)
        # div_impfr.innerHTML = f"from {module} import {names}"
        self.node_idlist.append(Importfrom.values['id'])
        self.a_counter += 1
        return IMPORTFROM

    def visit_alias(self,node):
        if node.asname == None:
            return f"{node.name}"
        else:
            return f"{node.name} as {node.asname}"

  
