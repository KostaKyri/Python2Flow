function tj_checkSyntax(code) {
    var inp = document.getElementById('inputArea');
    var outp = document.getElementById('output');
    TPyParser.rejectDeadCode = true;
    TPyParser.setLanguage("de");
    TPyParser.repeatStatement = true;
    TPyParser.evalMode = true;
    var err = TPyParser.checkSyntax(code);

    return err
  }