// Inhaltsverzeichnis:
// ***************************************************
// Funktionalität für Flussdiagramm (-animation):
// 01. Funktionalität für animation
// 02. Funktionalität für step-animation
// 03. Funktionalität für Erstellung der SVGs
// 04. Funktionalität für Erstellung der Leaderlines
// ***************************************************

// *************************************
// User-Interface-Funktionalität:
// 05. Funktionalität für Ace-Editor
// 06. Funktionalität für Split
// 07. Funktionalität für output-Fenster
// 08. Funktionalität für localStorage
// 09. Funktionalität für Burgermenü
// *************************************



// 01. Funktionalität für animation
// *****************************************************************************************
// Funktion, welche von debug.py aufgerufen wird, um die Zeilen im Ace-Editor bzw. 
// die Knoten und Linien im Flussdiagramm zu markieren:

var stop = true;
//function highlighter(n_abfolge,raw_lines,lineGroups, marker,line,step,time){
function highlighter(n_abfolge, raw_lines, lineGroups, stout_abfolge, marker, line, step, time) {
    console.log(stop)
    console.log('n_abfolge', n_abfolge[step])
    console.log('string', typeof n_abfolge[step][0] === 'string')

    // //Anzeige der Variablen im drawboardfenster:
    // let values = document.getElementById("output")
    // values.innerHTML = "";
    // let text = ""
    // let valArray = n_abfolge[step][2];
    // console.log(n_abfolge[step][2])
    // if (valArray !== undefined){
    //     for (let i = 0; i < valArray.length; i++){
    //         text += valArray[i][0] + " = " + valArray[i][1]+"<br>";
    //     }
    // }

    //values.innerHTML = text;

    // print-Ausgaben in output-Fenster ausgeben:
    if (stout_abfolge[step][1] !== undefined) {
        console.log(step, stout_abfolge[step][1])
        document.getElementById('output').innerHTML += stout_abfolge[step][1] + '\n'
    }


    const row = n_abfolge[step][0]

    // neu: FunkDefs einblenden:
    if (n_abfolge[step][2] === 1) {
        var parentDiv = document.getElementById("functions");
        var funcboxes = parentDiv.querySelectorAll('[id*="' + n_abfolge[step][1].slice(1) + '"]');
        funcboxes.forEach(function (child) {
            if (child.parentElement === parentDiv) {
                funcbox = child;
            }
        });

        console.log('parentDiv', parentDiv.id)
        console.log('funcbox', funcbox.id)
        // var funcbox = parentDiv.querySelector('[id*="' + n_abfolge[step][1].slice(1) + '"]');
        // console.log('parentDiv',parentDiv.id)
        // //console.log('funcbosId',funcbox)
        // console.log('id',n_abfolge[step+1][1].slice(1))

        funcbox.style.opacity = 1;

        //Marker für Codezeile, Linien & Nodes löschen:
        if (n_abfolge[step - 1][2] != 1) {
            document.getElementById(n_abfolge[step - 1][1] + '_id').classList.remove("highlight_Nodes")
            line.remove()
        }


        if (marker != null && typeof row === "number") {
            Editor.session.removeMarker(marker);
        }

        // Marker für Codezeile setzen:
        if (!(marker != null && typeof row !== "number")) {
            let Range = ace.require('ace/range').Range;
            let lineText = Editor.session.getLine(row);
            let yellowMarker = {
                startRow: row,
                startCol: lineText.indexOf(lineText.trim()[0]),
                endRow: row,
                endCol: lineText.length,
                className: 'highlight-yellow',
                type: 'text'
            };
            marker = Editor.session.addMarker(new Range(yellowMarker.startRow, yellowMarker.startCol, yellowMarker.endRow, yellowMarker.endCol), yellowMarker.className, yellowMarker.type);

        }
    }

    else {
        if (((n_abfolge[step][2] === 0 && n_abfolge[step + 1][2] === 1))) {
            for (var i = step + 2; i < n_abfolge.length; i++) {
                console.log("nnn", n_abfolge[i])
                if (n_abfolge[i][2] === 0) {
                    var start = n_abfolge[step][1]
                    var end = n_abfolge[i][1]
                    break;
                }
            }
        } else {
            var start = n_abfolge[step][1]
            var end = n_abfolge[step + 1][1]
        }


        // *****************************************************************************************
        // Variablen:
        // const start = n_abfolge[step][1]
        // const end = n_abfolge[step+1][1]
        console.log("StartEnd", start, end)


        const result = raw_lines.find(arr => arr[1] === start && arr[2] === end);
        time = document.getElementById('speed_slider').value;
        //console.log("step",step)
        //console.log(result)

        //Anzeige der len(Liste):
        // if (start.includes('_While_')){

        // }

        //Marker und output-Inhalt aus vorigen Debug-Vorgang löschen:
        if (step == 0) {
            const prevMarkers = Editor.session.getMarkers();
            if (prevMarkers) {
                const prevMarkersArr = Object.keys(prevMarkers);
                for (let item of prevMarkersArr) {
                    Editor.session.removeMarker(prevMarkers[item].id);
                }
            }

            function removeClassRecursive(element, className) {
                if (element.classList.contains(className)) {
                    element.classList.remove(className);
                }

                for (var i = 0; i < element.children.length; i++) {
                    var childElement = element.children[i];

                    removeClassRecursive(childElement, className);
                }
            }

            var parentDiv = document.getElementById('drawboard');
            var className = 'highlight_Nodes';

            removeClassRecursive(parentDiv, className);

            document.getElementById("output").innerHTML = ""

        }

        //Marker für Codezeile, Linien & Nodes löschen:
        if (step != 0 && n_abfolge[step - 1][2] != 1) {
            document.getElementById(n_abfolge[step - 1][1] + '_id').classList.remove("highlight_Nodes")
            line.remove()
        }



        console.log('sfsdf', marker, row)
        if (marker != null && typeof row === "number") {
            Editor.session.removeMarker(marker);
        }

        // Marker für Codezeile setzen:
        if (!(marker != null && typeof row !== "number")) {
            let Range = ace.require('ace/range').Range;
            let lineText = Editor.session.getLine(row);
            let yellowMarker = {
                startRow: row,
                startCol: lineText.indexOf(lineText.trim()[0]),
                endRow: row,
                endCol: lineText.length,
                className: 'highlight-yellow',
                type: 'text'
            };
            marker = Editor.session.addMarker(new Range(yellowMarker.startRow, yellowMarker.startCol, yellowMarker.endRow, yellowMarker.endCol), yellowMarker.className, yellowMarker.type);

        }

        // Funktionsdiagramm öffnen:
        if (result[2].includes("_FuncDef_")) {
            var f = document.getElementById(result[2]);
            if (!f.nextElementSibling.classList.contains('show')) {
                f.nextElementSibling.classList.toggle("show");

                lineGroups.forEach(function (linegroup, key) {
                    if (key.substring(0, 2) === f.id.substring(0, 2)) {

                        linegroup.forEach(function (line) {
                            line[0].show("none");
                            line[0].position()
                        });
                        //const func_div = document.getElementById(result[2]);
                        const func_div = document.getElementById("functions");
                        func_div.click(); // löst ein Click-Event auf dem Element aus

                    };
                    // Pfeile repositionieren:
                    for (const line of raw_lines) {
                        line[0].position()
                    }
                });
            };
        };
        // Funktionsdiagramm schliessen:
        if (result[1].includes("_endFunc_")) {

            setTimeout(function () {
                var f = document.getElementById(result[1].substring(0, 2) + '_FuncDef_' + result[1].substring(result[1].length - 1));
                f.nextElementSibling.classList.toggle("show")

                lineGroups.forEach(function (linegroup, key) {
                    if (key.substring(0, 2) === f.id.substring(0, 2)) {

                        linegroup.forEach(function (line) {
                            line[0].hide("none");
                        });
                    };
                });
                // Pfeile repositionieren:
                for (const line of raw_lines) {
                    line[0].position()
                }
                line.position()
            }, time);
        }



        // Marker für Linien setzen:

        //console.log('result',result[1],result[2],result[3])
        console.log('result', result)

        // if(result[2].includes("_For_") && result[3] === "" ){
        if (result[2].includes("_For_") && result[4] === "bottom") {
            line = afor_line(result[1], result[2])

        } else if (result[1].includes("_IfoEl_") && result[2].includes("_endIfoEl_")) {
            line = aiff_line(result[1], result[2])

        } else if (result[1].includes("_While_") && result[2].includes("_endWhile_")) {
            line = awf_line(result[1], result[2])

        } else if (result[2].includes("_While_") && result[4] === "left") {
            line = awl_line(result[1], result[2])

            // } else if(result[2].includes("_el_")){
            //     line = aw_line(result[1],result[2])
        } else if (result[2].includes("_FuncDef_")) {
            line = a_connector1(result[1], result[2])
        } else if (result[1].includes("_endFunc_")) {
            line = a_connector2(result[1], result[2])

            //}else if(result[1].includes("_Break_") || (typeof n_abfolge[step][0] === 'string' && n_abfolge[step][0].includes("_Returns_"))){
        } else if (result[1].includes("_Break_") || n_abfolge[step][2] == "Returns") {

            line = a_break_line(result[1], result[2])

        } else {
            // console.log('a')
            line = a_line(result[1], result[2], result[3], result[4])
        }

        line.show('draw', { duration: time * 1, timing: 'linear' })
        //console.log(result[1]+'id')
        document.getElementById(result[1] + '_id').classList.add("highlight_Nodes")

        //*****************************************************************************************

    }


    step += 1

    // Nächsten Programmschritt mit Verzögerung einleiten bzw.
    // if (step < n_abfolge.length -1){
    if (step < n_abfolge.length - 2 && stop) {
        //setTimeout(highlighter,time,n_abfolge,raw_lines,lineGroups, marker,line,step,time)
        setTimeout(highlighter, time, n_abfolge, raw_lines, lineGroups, stout_abfolge, marker, line, step, time)
    }
    else {

        document.getElementById("flowchart_button").style.display = "block"
        document.getElementById("anim_button").style.display = "block"
        document.getElementById("step_anim_button").style.display = "block"
        document.getElementById("stop_button").style.display = "none"

        document.getElementById("flowchart_button-inactive").style.display = "none"
        document.getElementById("anim_button-inactive").style.display = "none"
        document.getElementById("step_anim_button-inactive").style.display = "none"
        document.getElementById("stop_button-inactive").style.display = "block"

        if (stop == false) {
            stop = true;
            var domobject = document.getElementById(n_abfolge[step - 1][1] + '_id')
            if (domobject !== null) {
                domobject.classList.remove("highlight_Nodes")
                line.remove();
            }

            Editor.session.removeMarker(marker);
        }
        else {
            if (n_abfolge[n_abfolge.length - 1][1] == "False") {

                setTimeout(function () {
                    Editor.session.removeMarker(marker);
                    console.log('sdds', n_abfolge[step - 1][1][0])
                    if (n_abfolge[step - 1][1][0] !== 'd') {
                        document.getElementById(n_abfolge[step - 1][1] + '_id').classList.remove("highlight_Nodes")
                        line.remove();
                    }
                    document.getElementById(n_abfolge[step][1] + '_id').classList.add("highlight_Nodes")
                    setTimeout(function () {
                        document.getElementById(n_abfolge[step][1] + '_id').classList.remove("highlight_Nodes")
                    }, time)
                }, time)
            }
            else {
                x = setTimeout(function () {
                    // console.log(n_abfolge);
                    Editor.session.removeMarker(marker);
                    document.getElementById(n_abfolge[step - 1][1] + '_id').classList.remove("highlight_Nodes")
                    line.remove();
                    document.getElementById(n_abfolge[step][1] + '_id').classList.add("highlight_NodesRed")
                    document.getElementById("output").innerHTML += "<br><span style='color:red;'>" + n_abfolge[n_abfolge.length - 1][0] + " " + n_abfolge[n_abfolge.length - 1][1] + " (line " + `${n_abfolge[step][0] + 1}` + ")" + "</span>";

                    const final_row = n_abfolge[step][0]
                    // console.log(final_row)
                    let Range = ace.require('ace/range').Range;
                    let lineText = Editor.session.getLine(final_row);
                    let yellowMarker = {
                        startRow: final_row,
                        startCol: lineText.indexOf(lineText.trim()[0]),
                        endRow: final_row,
                        endCol: lineText.length,
                        className: 'highlight-red',
                        type: 'text'
                    };
                    marker = Editor.session.addMarker(new Range(yellowMarker.startRow, yellowMarker.startCol, yellowMarker.endRow, yellowMarker.endCol), yellowMarker.className, yellowMarker.type);



                }, time)


            }
        }


    };

};

// *****************************************************************************************



// 02. Funktionalität für step-animation
// *****************************************************************************************
// Funktion, welche von debug2.py aufgerufen wird, um die Zeilen im Ace-Editor bzw. 
// die Knoten und Linien im Flussdiagramm zu markieren, wenn geklickt wird:

function highlighter2(n_abfolge, raw_lines, lineGroups, stout_abfolge, marker, line, step, time) {
    console.log("in")
    const row = n_abfolge[step][0];

    // print-Ausgaben in output-Fenster ausgeben:
    if (stout_abfolge[step][1] !== undefined) {
        console.log(step, stout_abfolge[step][1])
        document.getElementById('output').innerHTML += stout_abfolge[step][1] + '\n'
    }


    // neu: FunkDefs einblenden:
    if (n_abfolge[step][2] === 1) {
        var parentDiv = document.getElementById("functions");
        var funcboxes = parentDiv.querySelectorAll('[id*="' + n_abfolge[step][1].slice(1) + '"]');
        funcboxes.forEach(function (child) {
            if (child.parentElement === parentDiv) {
                funcbox = child;
            }
        });

        console.log('parentDiv', parentDiv.id)
        console.log('funcbox', funcbox.id)

        funcbox.style.opacity = 1;

        //Marker für Codezeile, Linien & Nodes löschen:
        if (n_abfolge[step - 1][2] != 1) {
            document.getElementById(n_abfolge[step - 1][1] + '_id').classList.remove("highlight_Nodes")
            line.remove()
            line = null
        }

        if (marker != null && typeof row === "number") {
            Editor.session.removeMarker(marker);
        }

        // Marker für Codezeile setzen:
        if (!(marker != null && typeof row !== "number")) {
            let Range = ace.require('ace/range').Range;
            let lineText = Editor.session.getLine(row);
            let yellowMarker = {
                startRow: row,
                startCol: lineText.indexOf(lineText.trim()[0]),
                endRow: row,
                endCol: lineText.length,
                className: 'highlight-yellow',
                type: 'text'
            };
            marker = Editor.session.addMarker(new Range(yellowMarker.startRow, yellowMarker.startCol, yellowMarker.endRow, yellowMarker.endCol), yellowMarker.className, yellowMarker.type);

        }
    }

    else {
        if (((n_abfolge[step][2] === 0 && n_abfolge[step + 1][2] === 1))) {
            for (var i = step + 2; i < n_abfolge.length; i++) {
                console.log("nnn", n_abfolge[i])
                if (n_abfolge[i][2] === 0) {
                    var start = n_abfolge[step][1]
                    var end = n_abfolge[i][1]
                    break;
                }
            }
        } else {
            var start = n_abfolge[step][1]
            var end = n_abfolge[step + 1][1]
        }


        // Variablen:
        // const start = n_abfolge[step][1]
        // const end = n_abfolge[step+1][1]



        const result = raw_lines.find(arr => arr[1] === start && arr[2] === end);
        console.log('result', result)

        //Marker aus vorigen Debug-Vorgang löschen:
        if (step == 0) {
            const prevMarkers = Editor.session.getMarkers();
            if (prevMarkers) {
                const prevMarkersArr = Object.keys(prevMarkers);
                for (let item of prevMarkersArr) {
                    Editor.session.removeMarker(prevMarkers[item].id);
                }
            }
        }
        //Marker für Codezeile, Linien & Nodes löschen:
        if (step != 0 && n_abfolge[step - 1][2] != 1) {
            document.getElementById(n_abfolge[step - 1][1] + '_id').classList.remove("highlight_Nodes")
            line.remove()
        }
        if (marker != null && typeof row === "number") {
            Editor.session.removeMarker(marker);
        }

        // Marker für Codezeile setzen:
        if (!(marker != null && typeof row !== "number")) {
            let Range = ace.require('ace/range').Range;
            let lineText = Editor.session.getLine(row);
            let yellowMarker = {
                startRow: row,
                startCol: lineText.indexOf(lineText.trim()[0]),
                endRow: row,
                endCol: lineText.length,
                className: 'highlight-yellow',
                type: 'text'
            };
            marker = Editor.session.addMarker(new Range(yellowMarker.startRow, yellowMarker.startCol, yellowMarker.endRow, yellowMarker.endCol), yellowMarker.className, yellowMarker.type);

        }

        // Funktionsdiagramm öffnen:
        if (result[2].includes("_FuncDef_")) {
            var f = document.getElementById(result[2]);

            if (!f.nextElementSibling.classList.contains('show')) {
                f.nextElementSibling.classList.toggle("show");

                lineGroups.forEach(function (linegroup, key) {
                    if (key.substring(0, 2) === f.id.substring(0, 2)) {

                        linegroup.forEach(function (line) {
                            line[0].show("none");
                            line[0].position()
                        });
                        //const func_div = document.getElementById(result[2]);
                        const func_div = document.getElementById("functions");
                        func_div.click(); // löst ein Click-Event auf dem Element aus

                    };
                    // Pfeile repositionieren:
                    for (const line of raw_lines) {
                        line[0].position()
                    }
                });
            };
        };
        // Funktionsdiagramm schliessen:
        if (result[1].includes("_endFunc_")) {
            console.log(result[1].substring(0, 2) + '_FuncDef_' + result[1].substring(result[1].length - 1))
            setTimeout(function () {
                var f = document.getElementById(result[1].substring(0, 2) + '_FuncDef_' + result[1].substring(result[1].length - 1));
                f.nextElementSibling.classList.toggle("show")

                lineGroups.forEach(function (linegroup, key) {
                    if (key.substring(0, 2) === f.id.substring(0, 2)) {

                        linegroup.forEach(function (line) {
                            line[0].hide("none");
                        });
                    };
                });
                // Pfeile repositionieren:
                for (const line of raw_lines) {
                    line[0].position()
                }
                line.position()
            }, time);
        }



        // Marker für Linien setzen:
        if (result[2].includes("_For_") && result[4] === "bottom") {
            line = afor_line(result[1], result[2])

        } else if (result[1].includes("_IfoEl_") && result[2].includes("_endIfoEl_")) {
            line = aiff_line(result[1], result[2])

        } else if (result[1].includes("_While_") && result[2].includes("_endWhile_")) {
            line = awf_line(result[1], result[2])

        } else if (result[2].includes("_While_") && result[4] === "left") {
            line = awl_line(result[1], result[2])

            // } else if(result[2].includes("_el_")){
            //     line = aw_line(result[1],result[2])
        } else if (result[2].includes("_FuncDef_")) {
            line = a_connector1(result[1], result[2])
        } else if (result[1].includes("_endFunc_")) {
            line = a_connector2(result[1], result[2])


            console.log('n_abfolge[step][2]', n_abfolge[step][2])
            //}else if(result[1].includes("_Break_") || (typeof n_abfolge[step][0] === 'string' && n_abfolge[step][0].includes("_Returns_"))){
        } else if (result[1].includes("_Break_") || n_abfolge[step][2] == "Returns") {

            line = a_break_line(result[1], result[2])

        } else {
            line = a_line(result[1], result[2], result[3], result[4])
        }
        line.show('draw', { duration: time, timing: 'linear' })
        document.getElementById(result[1] + '_id').classList.add("highlight_Nodes")
    }

    return [marker, line];

};

function deleteMarker(marker, line, d, step, time, error) {
    console.log(line)
    console.log(d)
    console.log(step - 1)
    console.log('d', d[step - 1][1])
    if (d[step - 1][1][0] !== 'd') {
        document.getElementById(d[step - 1][1] + '_id').classList.remove("highlight_Nodes")
        line.remove();

    }
    if (error !== "False") {
        document.getElementById(d[step][1] + '_id').classList.add("highlight_NodesRed")
    } else {
        document.getElementById(d[step][1] + '_id').classList.add("highlight_Nodes")
    }
    Editor.session.removeMarker(marker);
    if (error == "False") {
        setTimeout(function () {
            document.getElementById(d[step][1] + '_id').classList.remove("highlight_Nodes")
        }, time)
    } else {
        const row = d[step][0]
        if (!(marker != null && typeof row !== "number")) {
            let Range = ace.require('ace/range').Range;
            let lineText = Editor.session.getLine(row);
            let yellowMarker = {
                startRow: row,
                startCol: lineText.indexOf(lineText.trim()[0]),
                endRow: row,
                endCol: lineText.length,
                className: 'highlight-red',
                type: 'text'
            };
            marker = Editor.session.addMarker(new Range(yellowMarker.startRow, yellowMarker.startCol, yellowMarker.endRow, yellowMarker.endCol), yellowMarker.className, yellowMarker.type);

        }
    }
};

function deleteMarkerAfterStopAnim(marker, line, d, step) {
    console.log(d[step - 1][1][0] !== 'd')
    if ((document.getElementById(d[step - 1][1] + '_id') !== null || d[step - 1][1] !== undefined) && d[step - 1][1][0] !== 'd') {
        document.getElementById(d[step - 1][1] + '_id').classList.remove("highlight_Nodes")
        line.remove();
    }
    Editor.session.removeMarker(marker);
}

// *****************************************************************************************



// 03. Funktionalität für Erstellung der SVGs
// *****************************************************************************************
function createSVG(div) {

    const colortheme_bright = {
        'nodetext': '#000000',
        'border': '#000000',
        'terminal': '#F4E2DE',
        // 'funcDef':'#2CB077',
        'funcDef': '#87AAAA',
        // 'defCall': '#92CC89',
        'defCall': '#87AAAA',
        'call': '#B7D2C3',
        // 'call':'#6CE6B5',
        'defCallAssign': 'linear-gradient(to right, #FF0000, #0000FF)',
        // 'call': '#B2F8A7',
        // 'default': '#FFF6B1',
        'default': '#F6EABE',
        'io': '#D9AA55',
        // 'io': '#D9AA55',
        // 'io': '#FFE3B0',
        'if': '#FF8593',
        'while': '#FFC088',
        'for': '#99E2FF',
        'linetext': '#000000',
        'line': '#000000',
    }


    const divContainer = div
    //const divContainer = document.getElementByClass(cls);
    let innertext = divContainer.textContent
    divContainer.textContent = ''

    const svgNS = "http://www.w3.org/2000/svg";
    const svgContainer = document.createElementNS(svgNS, "svg");
    svgContainer.classList = "nodesvg"
    //svgContainer.setAttribute("id", `${div.id}_id`);
    try {
        divContainer.appendChild(svgContainer);
    }
    catch (error) {
        console.log(error.message);

    }

    if (divContainer.classList[0] == 'Terminal') {
        const text = document.createElementNS(svgNS, "text");
        text.textContent = innertext
        text.setAttribute("fill", colortheme_bright['nodetext']);
        svgContainer.appendChild(text);

        const textWidth = text.getComputedTextLength();
        var fontsize = parseInt(getComputedStyle(text).getPropertyValue('font-size'), 10);
        text.setAttribute("x", `${textWidth / 2 + 11}`)
        text.setAttribute("y", fontsize + 12)

        const ellipse = document.createElementNS(svgNS, "ellipse");
        ellipse.classList.add("figuresvg", "terminal")

        ellipse.setAttribute("cx", `${textWidth + 12}`)
        ellipse.setAttribute("cy", fontsize + 7)
        ellipse.setAttribute("rx", `${textWidth + 10}`)
        ellipse.setAttribute("ry", `${fontsize + 5}`)
        ellipse.setAttribute("fill", colortheme_bright['terminal']);
        ellipse.setAttribute("stroke", colortheme_bright['border']);
        ellipse.setAttribute("stroke-width", "2");
        ellipse.setAttribute("id", `${div.id}_id`);

        svgContainer.appendChild(ellipse);

        svgContainer.insertBefore(ellipse, svgContainer.firstChild);
        const boundingBox = svgContainer.getBBox();
        svgContainer.setAttribute("width", boundingBox.width + 3);
        svgContainer.setAttribute("height", boundingBox.height + 3);
    }

    else if (divContainer.classList[0] == 'Assign' || divContainer.classList[0] == 'Expression') {
        const text = document.createElementNS(svgNS, "text");
        text.textContent = innertext
        text.setAttribute("fill", colortheme_bright['nodetext']);
        svgContainer.appendChild(text);

        const textWidth = text.getComputedTextLength();
        var fontsize = parseInt(getComputedStyle(text).getPropertyValue('font-size'), 10);
        text.setAttribute("x", 17)
        text.setAttribute("y", fontsize + 7)

        const rect = document.createElementNS(svgNS, "rect");
        rect.classList.add("figuresvg", "default")

        //rect.setAttribute('x', `${(svgContainer.getAttribute("width")-svgContainer.getAttribute("width"))/2}`);
        // rect.setAttribute('x', 8);

        rect.setAttribute('width', `${textWidth + 30}`);
        rect.setAttribute('height', `${fontsize + 15}`);
        rect.setAttribute('rx', 10);
        rect.setAttribute('ry', 10);

        rect.setAttribute("fill", colortheme_bright['default']);
        rect.setAttribute("stroke", colortheme_bright['border']);
        rect.setAttribute("stroke-width", "2");
        rect.setAttribute("id", `${div.id}_id`);
        svgContainer.insertBefore(rect, svgContainer.firstChild);

        const boundingBox = svgContainer.getBBox();
        svgContainer.setAttribute("width", boundingBox.width + 3);
        svgContainer.setAttribute("height", boundingBox.height + 3);

        rect.setAttribute('x', `${(svgContainer.getAttribute("width") - rect.getAttribute("width")) / 2}`);
        rect.setAttribute('y', `${(svgContainer.getAttribute("height") - rect.getAttribute("height")) / 2}`);
    }

    else if (divContainer.classList[0] == 'Call' || divContainer.classList[0] == 'DefCall' || divContainer.classList[0] == 'FuncDef' || divContainer.classList[0] == 'DefCallAssign' || divContainer.classList[0] == 'DefCallIO' || divContainer.classList[0] == 'DefCallReturn') {
        const text = document.createElementNS(svgNS, "text");
        text.textContent = innertext
        text.setAttribute("fill", colortheme_bright['nodetext']);
        svgContainer.appendChild(text);

        const textWidth = text.getComputedTextLength();
        var fontsize = parseInt(getComputedStyle(text).getPropertyValue('font-size'), 10);
        text.setAttribute("x", 27)
        text.setAttribute("y", fontsize + 7)

        const line1 = document.createElementNS(svgNS, "line");
        line1.classList = "figuresvg"

        line1.setAttribute("x1", 12)
        line1.setAttribute("y1", 3)
        line1.setAttribute("x2", 12)
        line1.setAttribute("y2", `${fontsize + 18}`)
        line1.setAttribute("stroke", colortheme_bright['border']);
        line1.setAttribute("stroke-width", "2");
        svgContainer.insertBefore(line1, svgContainer.firstChild);

        const line2 = document.createElementNS(svgNS, "line");
        line2.classList = "figuresvg"

        line2.setAttribute("x1", `${textWidth + 42}`)
        line2.setAttribute("y1", 3)
        line2.setAttribute("x2", `${textWidth + 42}`)
        line2.setAttribute("y2", `${fontsize + 18}`)
        line2.setAttribute("stroke", colortheme_bright['border']);
        line2.setAttribute("stroke-width", "2");
        svgContainer.insertBefore(line2, svgContainer.firstChild);

        const rect = document.createElementNS(svgNS, "rect");
        rect.classList = "figuresvg"

        rect.setAttribute('width', `${textWidth + 50}`);
        rect.setAttribute('height', `${fontsize + 15}`);
        rect.setAttribute('rx', 10);
        rect.setAttribute('ry', 10);


        if (divContainer.classList[0] == 'Call') {
            rect.setAttribute("fill", colortheme_bright['call']);

        } else if (divContainer.classList[0] == 'DefCallAssign') {
            //muss noch richtig implementiert werden
            rect.setAttribute("fill", colortheme_bright['defCall']);

        } else if (divContainer.classList[0] == 'DefCallIO') {
            //muss noch richtig implementiert werden
            rect.setAttribute("fill", colortheme_bright['defCall']);

        } else if (divContainer.classList[0] == 'DefCallReturn') {
            //muss noch richtig implementiert werden
            rect.setAttribute("fill", colortheme_bright['defCall']);

        } else if (divContainer.classList[0] == 'FuncDef') {
            rect.setAttribute("fill", colortheme_bright['funcDef']);

        } else {
            rect.setAttribute("fill", colortheme_bright['defCall']);
        }
        rect.setAttribute("stroke", colortheme_bright['border']);
        rect.setAttribute("stroke-width", "2");
        rect.setAttribute("id", `${div.id}_id`);
        svgContainer.insertBefore(rect, svgContainer.firstChild);

        const boundingBox = svgContainer.getBBox();
        svgContainer.setAttribute("width", boundingBox.width + 3);
        svgContainer.setAttribute("height", boundingBox.height + 3);

        rect.setAttribute('x', `${(svgContainer.getAttribute("width") - rect.getAttribute("width")) / 2}`);
        rect.setAttribute('y', `${(svgContainer.getAttribute("height") - rect.getAttribute("height")) / 2}`);
    }

    else if (divContainer.classList[0] == 'If') {
        const text = document.createElementNS(svgNS, "text");
        text.textContent = innertext
        text.setAttribute("fill", colortheme_bright['nodetext']);
        svgContainer.appendChild(text);

        const textWidth = text.getComputedTextLength();
        var fontsize = parseInt(getComputedStyle(text).getPropertyValue('font-size'), 10);
        text.setAttribute("x", 32)
        text.setAttribute("y", fontsize + 15)

        const polygon = document.createElementNS(svgNS, "polygon");
        polygon.classList = "figuresvg"

        polygon.setAttribute("points", `2,${fontsize / 2 + 17}    ${textWidth / 2 + 32},2    ${textWidth + 62},${fontsize / 2 + 17}    ${textWidth / 2 + 32},${fontsize + 32}`);
        polygon.setAttribute("fill", colortheme_bright['if']);
        polygon.setAttribute("stroke", colortheme_bright['border']);
        polygon.setAttribute("stroke-width", "2");

        polygon.setAttribute("id", `${div.id}_id`);
        svgContainer.insertBefore(polygon, svgContainer.firstChild);

        const boundingBox = svgContainer.getBBox();
        svgContainer.setAttribute("width", boundingBox.width + 4);
        svgContainer.setAttribute("height", boundingBox.height + 4);

    }

    else if (divContainer.classList[0] == 'endIf' || divContainer.classList[0] == 'endFor' || divContainer.classList[0] == 'endWhile' || divContainer.classList[0] == 'endFunc') {

        const circle = document.createElementNS(svgNS, "circle");
        circle.classList = "figuresvg"

        circle.setAttribute("cx", 12)
        circle.setAttribute("cy", 12)
        circle.setAttribute("r", 10)
        if (divContainer.classList[0] == 'endIf') {
            circle.setAttribute("fill", colortheme_bright['if']);
        } else if (divContainer.classList[0] == 'endFor') {
            circle.setAttribute("fill", colortheme_bright['for']);
        } else if (divContainer.classList[0] == 'endWhile') {
            circle.setAttribute("fill", colortheme_bright['while']);
        } else if (divContainer.classList[0] == 'endFunc') {
            circle.setAttribute("fill", colortheme_bright['funcDef']);
        }
        circle.setAttribute("stroke", colortheme_bright['border']);
        circle.setAttribute("stroke-width", "2");
        circle.setAttribute("id", `${div.id}_id`);
        svgContainer.appendChild(circle);

        const boundingBox = svgContainer.getBBox();
        svgContainer.setAttribute("width", boundingBox.width + 4);
        svgContainer.setAttribute("height", boundingBox.height + 4);

    }

    else if (divContainer.classList[0] == 'While') {
        const text = document.createElementNS(svgNS, "text");
        text.textContent = innertext
        text.setAttribute("fill", colortheme_bright['nodetext']);
        svgContainer.appendChild(text);

        const textWidth = text.getComputedTextLength();
        var fontsize = parseInt(getComputedStyle(text).getPropertyValue('font-size'), 10);
        text.setAttribute("x", 16)
        text.setAttribute("y", fontsize + 10)

        const polygon = document.createElementNS(svgNS, "polygon");
        polygon.classList = "figuresvg"

        polygon.setAttribute("points", `3,${fontsize / 2 + 12}    23,2    ${textWidth + 13},2    ${textWidth + 33},${fontsize / 2 + 12}    ${textWidth + 13},${fontsize + 22}     23,${fontsize + 22}`);

        //polygon.setAttribute("points", `0,${fontsize / 2 + 15} ${textWidth / 2 + 30},0 ${textWidth + 60},${fontsize / 2 + 15} ${textWidth / 2 + 30},${fontsize + 30}`);
        polygon.setAttribute("fill", colortheme_bright['while']);
        polygon.setAttribute("stroke", colortheme_bright['border']);
        polygon.setAttribute("stroke-width", "2");
        polygon.setAttribute("id", `${div.id}_id`);
        svgContainer.insertBefore(polygon, svgContainer.firstChild);

        const boundingBox = svgContainer.getBBox();
        svgContainer.setAttribute("width", boundingBox.width + 4);
        svgContainer.setAttribute("height", boundingBox.height + 4);
        //polygon.setAttribute("points", `0,${fontsize / 2 + 15} 30,0 ${textWidth},0 ${textWidth + 30},${fontsize / 2 + 15} ,${textWidth},${fontsize + 30}  ${30},${fontsize + 30}`);

    }

    else if (divContainer.classList[0] == 'For') {
        const text = document.createElementNS(svgNS, "text");

        // übersetzt for i in range() in repeat
        if (innertext.includes("range")) {
            const match = innertext.match(/range\((.*?)\)/);

            if (match) {
                const extractedString = match[1];
                innertext = `repeat ${extractedString}:`;
            }
        }
        text.textContent = innertext
        text.setAttribute("fill", colortheme_bright['nodetext']);
        svgContainer.appendChild(text);

        const textWidth = text.getComputedTextLength();
        var fontsize = parseInt(getComputedStyle(text).getPropertyValue('font-size'), 10);
        text.setAttribute("x", 18)
        text.setAttribute("y", fontsize + 9)

        const polygon = document.createElementNS(svgNS, "polygon");
        polygon.classList = "figuresvg"

        polygon.setAttribute("points", `3,${fontsize / 2 + 13}    23,2    ${textWidth + 13},2    ${textWidth + 33},${fontsize / 2 + 12}    ${textWidth + 13},${fontsize + 22}     23,${fontsize + 22}`);

        //polygon.setAttribute("points", `0,${fontsize / 2 + 15} ${textWidth / 2 + 30},0 ${textWidth + 60},${fontsize / 2 + 15} ${textWidth / 2 + 30},${fontsize + 30}`);
        polygon.setAttribute("fill", colortheme_bright['for']);
        polygon.setAttribute("stroke", colortheme_bright['border']);
        polygon.setAttribute("stroke-width", "2");
        polygon.setAttribute("id", `${div.id}_id`);
        svgContainer.insertBefore(polygon, svgContainer.firstChild);

        const boundingBox = svgContainer.getBBox();
        svgContainer.setAttribute("width", boundingBox.width + 3);
        svgContainer.setAttribute("height", boundingBox.height + 3);
        //polygon.setAttribute("points", `0,${fontsize / 2 + 15} 30,0 ${textWidth},0 ${textWidth + 30},${fontsize / 2 + 15} ,${textWidth},${fontsize + 30}  ${30},${fontsize + 30}`);

    }

    else if (divContainer.classList[0] == 'IO' || divContainer.classList[0] == 'AssignIO') {
        const text = document.createElementNS(svgNS, "text");
        text.textContent = innertext
        text.setAttribute("fill", colortheme_bright['nodetext']);
        svgContainer.appendChild(text);

        const textWidth = text.getComputedTextLength();
        var fontsize = parseInt(getComputedStyle(text).getPropertyValue('font-size'), 10);
        text.setAttribute("x", 26)
        text.setAttribute("y", fontsize + 7)

        const polygon = document.createElementNS(svgNS, "polygon");
        polygon.classList = "figuresvg"

        polygon.setAttribute("points", `17,2    ${textWidth + 47},2    ${textWidth + 32},${fontsize + 17}     2,${fontsize + 17}`);
        polygon.setAttribute("fill", colortheme_bright['io']);
        polygon.setAttribute("stroke", colortheme_bright['border']);
        polygon.setAttribute("stroke-width", "2");
        polygon.setAttribute("id", `${div.id}_id`);
        svgContainer.insertBefore(polygon, svgContainer.firstChild);

        const boundingBox = svgContainer.getBBox();
        svgContainer.setAttribute("width", boundingBox.width + 3);
        svgContainer.setAttribute("height", boundingBox.height + 3);
    }

}
// *****************************************************************************************



// 04. Funktionalität für Erstellung der Leaderlines
// *****************************************************************************************
// Funktionen, um die verschiedenen Linien zu erzeugen
function lineCreator(lineData) {
    // console.log(lineData)
    if (lineData.get('lineType') === 'default_line') {
        return default_line(lineData)
    } else if (lineData.get('lineType') === 'connector') {
        return connector(lineData)
    } else if (lineData.get('lineType') === 'break_line') {
        return break_line(lineData)
    } else if (lineData.get('lineType') === 'for_line') {
        return for_line(lineData)
    } else if (lineData.get('lineType') === 'done_line') {
        return done_line(lineData)
    } else if (lineData.get('lineType') === 'iff_line') {
        return iff_line(lineData)
    } else if (lineData.get('lineType') === 'ifelt_line') {
        return ifelt_line(lineData)
    } else if (lineData.get('lineType') === 'ifoelt_line') {
        return ifoelt_line(lineData)
    } else if (lineData.get('lineType') === 'wf_line') {
        return wf_line(lineData)
    } else if (lineData.get('lineType') === 'wl_line') {
        return wl_line(lineData)
    }
}

function prefix(id) {
    var indexOfFirstUnderscore = id.indexOf('_');
    var prefix = id.slice(0, indexOfFirstUnderscore);
    return prefix;
}

function suffix(id) {
    var indexOfFirstUnderscore = id.indexOf('_');
    var indexOfSecondUnderscore = id.indexOf('_', indexOfFirstUnderscore + 1);
    var suffix = id.slice(indexOfSecondUnderscore + 1);
    return suffix;
}


function default_line(lineData) {
    l = new LeaderLine(document.getElementById(lineData.get('source')), document.getElementById(lineData.get('target')),
        {
            path: 'grid',
            startSocket: lineData.get('anchor1'),
            endSocket: lineData.get('anchor2'),
            color: 'black',
            size: 2,
            outlineColor: '',
            endPlugSize: 0.8,
            startSocketGravity: 0,
            endSocketGravity: 0,
            hide: false,
            startLabel: LeaderLine.captionLabel({ offset: [0, -25], text: lineData.get('label'), color: 'black', outlineColor: '', fill: "black" }),
            endPlug: lineData.get('plug'),
        });
    return l;
}

function connector(lineData) {
    l = new LeaderLine(document.getElementById(lineData.get('source')), document.getElementById(lineData.get('target')),
        {
            path: 'fluid',
            startSocket: lineData.get('anchor1'),
            endSocket: lineData.get('anchor2'),
            // color: "#1AF09E",
            color: '#16FF00',
            size: 3,
            outlineColor: '',
            endPlugSize: 0.8,
            startSocketGravity: 200,
            endSocketGravity: 200,
            endPlug: "behind",
            hide: true
        });
    return l;
}

function break_line(lineData) {
    l = new LeaderLine(document.getElementById(lineData.get('source')), document.getElementById(lineData.get('target')),
        {
            path: 'fluid',
            startSocket: 'right',
            endSocket: 'right',
            // color: "#1AF09E",
            color: '#16FF00',

            size: 3,
            outlineColor: "",
            endPlugSize: 0.8,
            startSocketGravity: [200, 0],
            endSocketGravity: [200, 0],
            endPlug: "behind",
            hide: true
        });
    return l;
}

function for_line(lineData) {
    const koord = ["50%", "100%", "70%", "100%"]

    l = new LeaderLine(LeaderLine.pointAnchor(document.getElementById(lineData.get('source')), {
        x: koord[0], //50%,
        y: koord[1] //"100%"
    }),
        LeaderLine.pointAnchor(document.getElementById(lineData.get('target')), {
            x: koord[2], //"70%",
            y: koord[3] //"100%"
        }),
        {
            path: 'grid',
            color: 'black',
            size: 2,
            endPlugSize: 0.8,
            startSocketGravity: [0, 15],
            endSocketGravity: [0, 20],
            hide: false,
            endPlug: 'arrow1'
        });
    return l;
}

function done_line(lineData) {
    l = new LeaderLine(document.getElementById(lineData.get('source')), document.getElementById(lineData.get('target')),
        {
            path: 'grid',
            startSocket: lineData.get('anchor1'),
            endSocket: lineData.get('anchor2'),
            color: 'black',
            size: 2,
            outlineColor: '',
            endPlugSize: 0.8,
            startSocketGravity: 0,
            endSocketGravity: 0,
            hide: false,
            startLabel: LeaderLine.captionLabel({ offset: [25, -5], text: lineData.get('label'), color: 'black', outlineColor: "" }),
            endPlug: lineData.get('plug'),
        });
    return l;
}

function ifelt_line(lineData) {
    l = new LeaderLine(document.getElementById(lineData.get('source')), document.getElementById(lineData.get('target')),
        {
            path: 'grid',
            startSocket: lineData.get('anchor1'),
            endSocket: lineData.get('anchor2'),
            color: 'black',
            size: 2,
            outlineColor: '',
            endPlugSize: 0.8,
            startSocketGravity: 0,
            endSocketGravity: 0,
            hide: false,
            startLabel: LeaderLine.captionLabel({ offset: [-28, -25], text: lineData.get('label'), color: 'black', outlineColor: "" }),
            endPlug: lineData.get('plug'),
        });
    return l;
}

function ifoelt_line(lineData) {
    l = new LeaderLine(document.getElementById(lineData.get('source')), document.getElementById(lineData.get('target')),
        {
            path: 'grid',
            startSocket: lineData.get('anchor1'),
            endSocket: lineData.get('anchor2'),
            color: 'black',
            size: 2,
            outlineColor: '',
            endPlugSize: 0.8,
            startSocketGravity: 0,
            endSocketGravity: 0,
            hide: false,
            startLabel: LeaderLine.captionLabel({ offset: [10, -5], text: lineData.get('label'), color: 'black', outlineColor: "" }),
            endPlug: lineData.get('plug'),
        });
    return l;
}

function iff_line(lineData) {
    l = new LeaderLine(document.getElementById(lineData.get('source')), document.getElementById(lineData.get('target')),
        {
            path: 'grid',
            startSocket: lineData.get('anchor1'),
            endSocket: lineData.get('anchor2'),
            color: 'black',
            size: 2,
            endPlugSize: 0.8,
            startSocketGravity: document.getElementById(lineData.get('ef')).getBoundingClientRect().x - document.getElementById(lineData.get('source')).getBoundingClientRect().x - document.getElementById(lineData.get('source')).getBoundingClientRect().width + document.getElementById(lineData.get('ef')).getBoundingClientRect().width / 2,
            endSocketGravity: document.getElementById(lineData.get('ef')).getBoundingClientRect().x - document.getElementById(lineData.get('target')).getBoundingClientRect().x - document.getElementById(lineData.get('target')).getBoundingClientRect().width + document.getElementById(lineData.get('ef')).getBoundingClientRect().width / 2,
            hide: false,
            startLabel: LeaderLine.captionLabel({ offset: [5, -25], text: lineData.get('label'), color: 'black', outlineColor: "" }),
            endPlug: lineData.get('plug')
        });
    return l;
}

function wf_line(lineData) {
    l = new LeaderLine(document.getElementById(lineData.get('source')), document.getElementById(lineData.get('target')),
        {
            path: 'grid',
            startSocket: lineData.get('anchor1'),
            endSocket: lineData.get('anchor2'),
            color: 'black',
            size: 2,
            endPlugSize: 0.8,
            startSocketGravity: document.getElementById(lineData.get('ef')).getBoundingClientRect().x - document.getElementById(lineData.get('source')).getBoundingClientRect().x - document.getElementById(lineData.get('source')).getBoundingClientRect().width + document.getElementById(lineData.get('ef')).getBoundingClientRect().width / 2,
            endSocketGravity: document.getElementById(lineData.get('ef')).getBoundingClientRect().x - document.getElementById(lineData.get('target')).getBoundingClientRect().x - document.getElementById(lineData.get('target')).getBoundingClientRect().width + document.getElementById(lineData.get('ef')).getBoundingClientRect().width / 2,
            startLabel: LeaderLine.captionLabel({ offset: [0, -25], text: lineData.get('label'), color: 'black', outlineColor: "" }),
            hide: false,
            endPlug: lineData.get('plug')
        });
    return l;
}

function wl_line(lineData) {
    l = new LeaderLine(document.getElementById(lineData.get('source')), document.getElementById(lineData.get('target')),
        {
            path: 'grid',
            startSocket: lineData.get('anchor1'),
            endSocket: lineData.get('anchor2'),
            color: 'black',
            size: 2,
            endPlugSize: 0.8,
            startSocketGravity: 10, // document.getElementById(lineData.get('source')).getBoundingClientRect().x - document.getElementById(lineData.get('el')).getBoundingClientRect().x + document.getElementById(lineData.get('el')).getBoundingClientRect().width/2,
            endSocketGravity: document.getElementById(lineData.get('target')).getBoundingClientRect().x - document.getElementById(lineData.get('el')).getBoundingClientRect().x - document.getElementById(lineData.get('el')).getBoundingClientRect().width / 2,
            hide: false,
            endPlug: lineData.get('plug')
        });
    return l;
}

// animierte lines für Animation:

function a_line(source, target, anchor1 = "bottom", anchor2 = "top") {
    l = new LeaderLine(document.getElementById(source), document.getElementById(target),
        {
            path: 'grid',
            startSocket: anchor1,
            endSocket: anchor2,
            // color: "#1AF09E",
            color: '#16FF00',

            size: 3,
            outlineColor: "",
            endPlugSize: 0.8,
            startSocketGravity: 0,
            endSocketGravity: 0,
            endPlug: "behind",
            hide: true
        });
    return l;
}

function a_connector1(source, target, anchor1 = "right", anchor2 = "left") {

    l = new LeaderLine(document.getElementById(source), document.getElementById(target),
        {
            path: 'fluid',
            startSocket: anchor1,
            endSocket: anchor2,
            color: '#16FF00',

            // color: "#1AF09E", 
            size: 3,
            outlineColor: "",
            endPlugSize: 0.8,
            startSocketGravity: 200,
            endSocketGravity: 200,
            endPlug: "behind",
            hide: true
        });
    return l;
}

function a_connector2(source, target, anchor1 = "left", anchor2 = "right") {

    l = new LeaderLine(document.getElementById(source), document.getElementById(target),
        {
            path: 'fluid',
            startSocket: anchor1,
            endSocket: anchor2,
            // color: "#1AF09E",
            color: '#16FF00',

            size: 3,
            outlineColor: "",
            endPlugSize: 0.8,
            startSocketGravity: 200,
            endSocketGravity: 200,
            endPlug: "behind",
            hide: true
        });
    return l;
}

function a_break_line(source, target) {
    l = new LeaderLine(document.getElementById(source), document.getElementById(target),
        {
            path: 'fluid',
            startSocket: "right",
            endSocket: "right",
            color: '#16FF00',

            // color: "#1AF09E", 
            size: 3,
            outlineColor: "",
            endPlugSize: 0.8,
            startSocketGravity: [200, 0],
            endSocketGravity: [200, 0],
            endPlug: "behind",
            hide: true
        });
    return l;
}

function afor_line(source, target, koord = ["50%", "100%", "70%", "100%"]) {
    // function afor_line(source, target, koord = ["50%","100%","100%","50%"]){
    l = new LeaderLine(LeaderLine.pointAnchor(document.getElementById(source), {
        x: koord[0], //50%,
        y: koord[1] //"100%"
    }),
        LeaderLine.pointAnchor(document.getElementById(target), {
            x: koord[2], //"70%",
            y: koord[3] //"100%"
        }),
        {
            path: 'grid',
            color: '#16FF00',

            // color: "#1AF09E",
            size: 3,
            outlineColor: "",
            endPlugSize: 0.8,
            startSocketGravity: [0, 15],
            endSocketGravity: [0, 20],
            hide: true,
            endPlug: "behind"
        });
    return l;
}

function aiff_line(source, target, anchor1 = "right", anchor2 = "right") {
    l = new LeaderLine(document.getElementById(source), document.getElementById(target),
        {
            path: 'grid',
            startSocket: anchor1,
            endSocket: anchor2,
            // color: "#1AF09E",
            color: '#16FF00',

            size: 3,
            outlineColor: "",
            endPlugSize: 0.8,
            startSocketGravity: document.getElementById(`${prefix(source)}_e_${suffix(source)}`).getBoundingClientRect().x - document.getElementById(source).getBoundingClientRect().x - document.getElementById(source).getBoundingClientRect().width + document.getElementById(`${prefix(source)}_e_${suffix(source)}`).getBoundingClientRect().width / 2,
            endSocketGravity: document.getElementById(`${prefix(source)}_e_${suffix(source)}`).getBoundingClientRect().x - document.getElementById(target).getBoundingClientRect().x - document.getElementById(target).getBoundingClientRect().width + document.getElementById(`${prefix(source)}_e_${suffix(source)}`).getBoundingClientRect().width / 2,
            hide: true,
            endPlug: "behind"
        });
    return l;
}

function awf_line(source, target, anchor1 = "right", anchor2 = "right") {
    l = new LeaderLine(document.getElementById(source), document.getElementById(target),
        {
            path: 'grid',
            startSocket: anchor1,
            endSocket: anchor2,
            // color: "#1AF09E",
            color: '#16FF00',

            size: 3,
            outlineColor: "",
            endPlugSize: 0.8,
            startSocketGravity: document.getElementById(`${prefix(source)}_ef_${suffix(source)}`).getBoundingClientRect().x - document.getElementById(source).getBoundingClientRect().x - document.getElementById(source).getBoundingClientRect().width + document.getElementById(`${prefix(source)}_ef_${suffix(source)}`).getBoundingClientRect().width / 2,
            endSocketGravity: document.getElementById(`${prefix(source)}_ef_${suffix(source)}`).getBoundingClientRect().x - document.getElementById(target).getBoundingClientRect().x - document.getElementById(target).getBoundingClientRect().width + document.getElementById(`${prefix(source)}_ef_${suffix(source)}`).getBoundingClientRect().width / 2,
            hide: true,
            endPlug: "behind"
        });
    return l
}

function awl_line(source, target, anchor1 = "bottom", anchor2 = "left") {
    console.log("dfsdf", `${prefix(target)}_el_${suffix(target)}`)
    l = new LeaderLine(document.getElementById(source), document.getElementById(target),
        {
            path: 'grid',
            startSocket: anchor1,
            endSocket: anchor2,
            // color: "#1AF09E",
            color: '#16FF00',

            size: 3,
            outlineColor: "",
            endPlugSize: 0.8,
            // startSocketGravity: document.getElementById(`${prefix(target)}_el_${suffix(target)}`).getBoundingClientRect().x - document.getElementById(source).getBoundingClientRect().x - document.getElementById(source).getBoundingClientRect().width + document.getElementById(`${prefix(target)}_el_${suffix(target)}`).getBoundingClientRect().width / 2,
            // endSocketGravity: document.getElementById(`${prefix(target)}_el_${suffix(target)}`).getBoundingClientRect().x - document.getElementById(target).getBoundingClientRect().x - document.getElementById(target).getBoundingClientRect().width + document.getElementById(`${prefix(target)}_el_${suffix(target)}`).getBoundingClientRect().width / 2,
            startSocketGravity: 10, // document.getElementById(lineData.get('source')).getBoundingClientRect().x - document.getElementById(lineData.get('el')).getBoundingClientRect().x + document.getElementById(lineData.get('el')).getBoundingClientRect().width/2,
            endSocketGravity: document.getElementById(target).getBoundingClientRect().x - document.getElementById(`${prefix(target)}_el_${suffix(target)}`).getBoundingClientRect().x - document.getElementById(`${prefix(target)}_el_${suffix(target)}`).getBoundingClientRect().width / 2,

            hide: true,
            endPlug: "behind"
        });
    return l
}

// *****************************************************************************************


// 05. Funktionalität für Ace-Editor
// *****************************************************************************************
// Ace-Editor initialisieren:
Editor = ace.edit("editor");
//editor.setTheme("ace/theme/twilight");
// Editor.setTheme("ace/theme/idle_fingers");
Editor.setTheme("ace/theme/crimson_editor");
Editor.session.setMode("ace/mode/python");
Editor.session.setTabSize(4);
Editor.setOptions({
    //firstLineNumber: 0,
    fontSize: "11pt",
    enableBasicAutocompletion: true,
    enableLiveAutocompletion: true,
    highlightActiveLine: false
});

console.log("editor online")

function getCode() {
    return Editor.getValue();
}

function addMarker(line, cls) {
    console.log('marker set at ', line)
    let Range = ace.require('ace/range').Range;
    let lineText = Editor.session.getLine(line);
    let yellowMarker = {
        startRow: line,
        startCol: lineText.indexOf(lineText.trim()[0]),
        endRow: line,
        endCol: lineText.length,
        className: cls,
        type: 'text'
    };

    //Editor.session.addMarker(new Range(yellowMarker.startRow, 0, yellowMarker.endRow, 1), yellowMarker.className, 'fullLine');
    Editor.session.addMarker(new Range(yellowMarker.startRow, yellowMarker.startCol, yellowMarker.endRow, yellowMarker.endCol), yellowMarker.className, yellowMarker.type);
}

function removeMarker() {
    const prevMarkers = Editor.session.getMarkers();
    if (prevMarkers) {
        const prevMarkersArr = Object.keys(prevMarkers);
        for (let item of prevMarkersArr) {
            Editor.session.removeMarker(prevMarkers[item].id);
        }
    }
}

// *****************************************************************************************


// 06. Funktionalität für Split
// *****************************************************************************************
Split({
    columnGutters: [{
        track: 1,
        element: document.querySelector('.gutter-col-1'),
    }],
    rowGutters: [{
        track: 1,
        element: document.querySelector('.gutter-col-2'),
    }],
})
// *****************************************************************************************


// 07. Funktionalität für output-Fenster
// *****************************************************************************************
const handle = document.getElementById('handle');
const container = document.getElementById('output-container');

let isResizing = false;

handle.addEventListener('mousedown', (event) => {
    isResizing = true;
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', () => {
        isResizing = false;
        document.removeEventListener('mousemove', handleMouseMove);
    });
    console.log('isResizing', isResizing)
});

handle.addEventListener('touchstart', (event) => {
    isResizing = true;
    document.addEventListener('touchmove', handleMouseMove);
    document.addEventListener('touchend', () => {
        isResizing = false;
        document.removeEventListener('touchmove', handleMouseMove);
    });
    console.log('isResizing', isResizing)
});

function handleMouseMove(event) {
    if (isResizing) {
        const containerRect = container.getBoundingClientRect();
        const newHeight = containerRect.bottom - event.clientY;
        container.style.height = `${newHeight}px`;
        const drawboard = document.getElementById('drawboard')
        drawboard.style.height = `calc(100vh - 55px - ${newHeight}px)`;

    }
}
// *****************************************************************************************

// 08. Funktionalität für localStorage
// *****************************************************************************************
window.onload = function () {
    // Überprüfen, ob der Web Storage unterstützt wird
    if (typeof (Storage) !== "undefined") {
        // Überprüfen, ob ein gespeicherter Wert vorhanden ist
        if (localStorage.savedCode) {
            // Wenn ein Wert vorhanden ist, setze den gespeicherten Wert als Code im Ace Editor
            var editor = ace.edit("editor");
            editor.setValue(localStorage.savedCode);
        }

        if (localStorage.getItem('switchvalue') !== null) {
            // Wenn ein Wert vorhanden ist, setze den gespeicherten Wert als Code im Ace Editor
            document.getElementById('switch_blackwhite').checked = JSON.parse(localStorage.switchvalue);
        }
    }
};

window.addEventListener('beforeunload', function (event) {
    // Hier können Sie Code ausführen, bevor die Seite neu geladen wird
    // Zum Beispiel eine Bestätigungsnachricht anzeigen
    this.document.getElementById("zoom_slider").value = 1;
    this.document.getElementById("speed_slider").value = 2000;

    if (typeof (Storage) !== "undefined") {
        // Zugriff auf den Ace Editor und Abrufen des aktuellen Codes
        var editor = ace.edit("editor");
        var code = editor.getValue();
        // Speichern des Codes im lokalen Speicher
        localStorage.savedCode = code;
        localStorage.switchvalue = document.querySelector('#switch_blackwhite').checked;
        console.log(this.localStorage.switchvalue)
    }
});

// *****************************************************************************************



// 09. Funktionalität für Burgermenü
// *****************************************************************************************
// Downoad code:
function downloadCode() {
    // Get the code from the Ace Editor
    var code = Editor.getValue();

    console.log(code)
    // Create a Blob containing the code
    var blob = new Blob([code], { type: "text/plain" });

    // Create a download link
    var link = document.createElement("a");
    link.href = window.URL.createObjectURL(blob);
    link.download = "my_code.py"; // Set the filename with the desired extension

    // Append the link to the body and trigger the click event
    document.body.appendChild(link);
    link.click();

    // Remove the link from the body
    document.body.removeChild(link);
}

//Upload code
function loadFile() {
    var fileInput = document.getElementById('fileInput');
    var file = fileInput.files[0];

    if (file) {
        var reader = new FileReader();

        reader.onload = function (e) {
            // Set the content of the Ace Editor to the file's content
            Editor.setValue(e.target.result);
        };

        // Read the file as text
        reader.readAsText(file);
    }
}

function toggleFullscreen() {
    if (document.fullscreenElement) {
        // Exit fullscreen if already in fullscreen
        document.exitFullscreen();
    } else {
        // Request fullscreen
        document.documentElement.requestFullscreen().catch(err => {
            console.error('Error attempting to enable fullscreen:', err);
        });
    }
}

function printPage() {
    var menu = document.getElementById("nav")
    menu.style.display = "none";

    window.print()
    menu.style.display = "flex";

}


// Funktion zum Einblenden des Overlays
function openOverlay() {
    document.getElementById('overlay').style.display = 'flex';
}

// Funktion zum Ausblenden des Overlays
function closeOverlay() {
    document.getElementById('overlay').style.display = 'none';
}



// *****************************************************************************************

